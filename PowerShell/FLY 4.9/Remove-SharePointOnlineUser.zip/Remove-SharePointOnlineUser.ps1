<#
.DESCRIPTION
  Removes a user from all the groups he is currently in.
.PARAMETER LoginName
  The user to be removed from site collection
.PARAMETER AdministrationCenterUrl
  The URL of the SharePoint Online Administration Center site.
.PARAMETER Path
  Path to the file whose contents are the site collection to remove the user from.
#>
Function Remove-SharePointOnlineUser {
    [cmdletbinding(DefaultParameterSetName='AllSites')]
    Param(
            [Parameter(ParameterSetName='AllSites', Mandatory=$true)]
            [Parameter(ParameterSetName='PartiallySites', Mandatory=$true)]
            [String]
            $LoginName,

            [Parameter(ParameterSetName='AllSites', Mandatory=$true)]
            [Parameter(ParameterSetName='PartiallySites', Mandatory=$true)]
            [String]
            $AdministrationCenterUrl,

            [Parameter(ParameterSetName='PartiallySites', Mandatory=$true)]
            [String]
            $Path
        )

    $DependencyModule = Get-Module -Name Microsoft.Online.SharePoint.PowerShell -ListAvailable | Select Name,Version

    IF(-not $DependencyModule){
        Throw 'Before you get started using PowerShell to manage SharePoint Online users, make sure that the SharePoint Online Management Shell is installed.'
    }

    Import-Module Microsoft.Online.Sharepoint.PowerShell -DisableNameChecking -ErrorAction Stop

    Connect-SPOService -Url $AdministrationCenterUrl -ErrorAction Stop

    IF($PSCmdlet.ParameterSetName -eq 'PartiallySites'){
        Import-Csv -Path $Path -ErrorAction Stop | ForEach-Object {
            IF(-not [System.String]::IsNullOrEmpty($_.Url)){
                $Site = $_
                Try{
                    Set-SPOUser -Site $Site.Url -LoginName $LoginName -IsSiteCollectionAdmin $False
                    Write-Host "`nUser has been removed from the site $($Site.Url) successfully." -ForegroundColor Green
                }Catch{
                    Write-Host "`nError occurred while removing user from the site $($Site.Url)" -ForegroundColor Red
                    Write-Host "`n$($_.Exception.Message)" -ForegroundColor Red 
                }
            }
        }
    }

    IF($PSCmdlet.ParameterSetName -eq 'AllSites'){
        Get-SPOSite -IncludePersonalSite $true -Limit All -ErrorAction Stop | ForEach-Object {
            $Site = $_
            Try{
                Set-SPOUser -Site $Site.Url -LoginName $LoginName -IsSiteCollectionAdmin $False
                Write-Host "`nUser has been removed from the site $($Site.Url) successfully." -ForegroundColor Green
            }Catch{
                Write-Host "`nError occurred while removing user from the site $($Site.Url)" -ForegroundColor Red
                Write-Host "`n$($_.Exception.Message)" -ForegroundColor Red
            }
        }
    }
}