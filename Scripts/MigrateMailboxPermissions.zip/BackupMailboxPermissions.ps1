﻿<# /********************************************************************
 *
 *  PROPRIETARY and CONFIDENTIAL
 *
 *  This file is licensed from, and is a trade secret of:
 *
 *                   AvePoint, Inc.
 *                   525 Washington Blvd, Suite 1400
 *                   Jersey City, NJ 07310
 *                   United States of America
 *                   Telephone: +1-201-793-1111
 *                   WWW: www.avepoint.com
 *
 *  Refer to your License Agreement for restrictions on use,
 *  duplication, or disclosure.
 *
 *  RESTRICTED RIGHTS LEGEND
 *
 *  Use, duplication, or disclosure by the Government is
 *  subject to restrictions as set forth in subdivision
 *  (c)(1)(ii) of the Rights in Technical Data and Computer
 *  Software clause at DFARS 252.227-7013 (Oct. 1988) and
 *  FAR 52.227-19 (C) (June 1987).
 *
 *  Copyright © 2017-2024 AvePoint® Inc. All Rights Reserved. 
 *
 *  Unpublished - All rights reserved under the copyright laws of the United States.
 */ #>
$invocation = (Get-Variable MyInvocation).Value
$currentPath = (Get-Item $invocation.MyCommand.Path).Directory.FullName
."$currentPath\Common\LogFuncs.ps1"
$timestamp = Get-Date -UFormat %Y%m%d%H%M%S
$reportPath="$currentPath\GetMailboxPermissions_$timestamp.csv";
$logName="BackupMailboxPermissions_$timestamp.log";
$ret = @()
$csvPath= "$currentPath\MailboxMappings.csv"
$csvContent =@()
$Script:ErrorActionPreference = "Stop"

try
{ 
 Log-Initialize -Path "$CurrentPath\Logs" -Name $logName
 $logFullPath = "$CurrentPath\Logs\$logName"
}
catch
{
  Write-Error "Failed to initialize the logs. Details: $($_.Exception.Message)"
  exit
}
if (test-path $csvPath)
{
  $csvContent= Import-Csv $csvPath
  $totalCount = $csvContent | Measure-Object | Select-Object -Expand Count
}
else
{
   Log-Error -Message  "Job failed. Failed to retrieve the `"MailboxMappings.csv`" file in the $($csvPath) directory."
   exit
}
function FormatUser([string]$user)
{
    $result = $user
    if($user.Contains("/"))
    {
       $result = $user.Substring($user.LastIndexOf("/") + 1) 
    }
    if($user.Contains("\"))
    {
       $result = $user.Substring($user.LastIndexOf("\") + 1)
    }
    return $result
}
function GetNameFromAddress([string]$address)
{
    Log-Info "Start to retrieve the mailbox name from the email address ""$($address)""."
    $mailbox = Get-Mailbox -Identity $address | Select-Object Name -ErrorAction Stop
    $result = $mailbox.Name
    Log-Info "Successfully retrieved the mailbox name ""$($mailbox.Name)"" from the email address ""$($address)""."
    return $result
}
function GetAddressFromName([string]$name)
{
    $result = $name
    try
    {
        $recipient = Get-Recipient -Identity $name | Select-Object -property PrimarySmtpAddress -ErrorAction Stop
        $result = $recipient.PrimarySmtpAddress
    }
    catch
    {
        $errorMessage = "Failed to retrieve the email address from the name ""$($name)"". Details: $($_.Exception.Message)"
        Log-Error -Message $errorMessage -ConsoleInfo $false
    }
    return $result
}
function GetOnPremMailboxSendAs([string]$name)
{
    [System.Collections.ArrayList]$sendAsPermission = @()
    $resultList = Get-AdPermission -Identity $name |Select-Object -property User,ExtendedRights,IsInherited -ErrorAction Stop
    foreach($prem in $resultList)
    {
        Log-Info "User:$($prem.User). ExtendedRights:$($prem.ExtendedRights). IsInherited:$($prem.IsInherited)." -ConsoleInfo $false

        if($prem.ExtendedRights -like "Send-As" -and $prem.IsInherited -ne $true -and $prem.User -like "*\*"`
            -and $prem.User -notlike "NT AUTHORITY\SELF"`
            -and $prem.User -notlike "NT-AUTORITÄT\SELBST"`
            -and $prem.User -notlike "NT AUTHORITY\ZELF")
        {
            [string]$tempName = FormatUser($prem.User)
            [string]$tempAddress = GetAddressFromName($tempName)
            $sendAsPermission.Add($tempAddress) | out-null
        }
        else
        {
            Log-Info "Skip this permission: $($prem.User)." -ConsoleInfo $false
        }
    }
    return $sendAsPermission
}

function GetMailboxSendOnBehalf([string]$address)
{
    [System.Collections.ArrayList]$result = @()
    $sendOBPermission = Get-Mailbox -Identity $address | Select-Object GrantSendOnBehalfTo            
    foreach($permission in $sendOBPermission.GrantSendOnBehalfTo)
    {
        [string]$tempName = FormatUser($permission)
        [string]$tempAddress = GetAddressFromName($tempName)
        $result.Add($tempAddress) | out-null
    }
    return $result
}

function GetMailboxFullAccess([string]$address)
{
    [System.Collections.ArrayList]$result = @()
    $fullAccesses = Get-MailboxPermission -Identity $address | Select-Object User,IsInherited
    foreach($fa in $fullAccesses)
    {
        Log-Info "User:$($fa.User). ExtendedRights:$($fa.ExtendedRights). IsInherited:$($fa.IsInherited)." -ConsoleInfo $false
        if(($fa.User -like "NT AUTHORITY\SELF")`
            -or ($fa.User -like "NT-AUTORITÄT\SELBST")`
            -or ($fa.User -like "NT AUTHORITY\ZELF")`
            -or ($fa.User -like "*\Exchange Servers")`
            -or ($fa.User -like "*\Exchange Trusted Subsystem")`
            -or ($fa.IsInherited -eq $true))
        {
            Log-Info "Skip this permission. User:$($fa.User). IsInherited:$($fa.IsInherited)" -ConsoleInfo $false
        }
        else
        {
            [string]$tempName = FormatUser($fa.User)
            [string]$tempAddress = GetAddressFromName($tempName)
            $result.Add($tempAddress) | out-null
        }
    }
    return $result
}

#main
$failedMailboxCount = 0
try      
{     
    if($csvContent)
    {
        foreach($mailbox in $csvContent)
        {
            if($mailbox.'Source Email Address' -and $mailbox.'Destination Email Address')
            {
                #Get mailbox name
                try
                {
                    $username = GetNameFromAddress($mailbox.'Source Email Address')
                }
                catch
                {
                    $failedMailboxCount = $failedMailboxCount + 1
                    $errorMessage = "Failed to retrieve the mailbox name from the email address ""$($mailbox.'Source Email Address')"" configured in the ""MailboxMappings.csv"" file. Details: $($_.Exception.Message)"
                    Log-Error -Message $errorMessage  
                    $mobj = New-Object -TypeName PSCustomObject
                    $mobj | Add-Member -MemberType NoteProperty -Name "Source Email Address" -Value $mailbox.'Source Email Address'
                    $mobj | Add-Member -MemberType NoteProperty -Name "Destination Email Address" -Value $mailbox.'Destination Email Address'
                    $mobj | Add-Member -MemberType NoteProperty -Name "Permission" -Value 'All permissions'
                    $mobj | Add-Member -MemberType NoteProperty -Name "User" -Value ''
                    $mobj | Add-Member -MemberType NoteProperty -Name "Status" -Value 'Failed'
                    $mobj | Add-Member -MemberType NoteProperty -Name "Comment" -Value $errorMessage
                    $ret += $mobj
                    continue
                }

                $hasPermissions = $false
                #GET Send As 
                try
                {        
                    Log-Info "Start to retrieve the ""Send as"" permission of the mailbox ""$($mailbox.'Source Email Address')""."      
                    $sendAsList = GetOnPremMailboxSendAs($username)
                    if($sendAsList)
                    {
                        $hasPermissions = $true
                        foreach($sendAs in $sendAsList)
                        {
                            $mobj = New-Object -TypeName PSCustomObject
                            $mobj | Add-Member -MemberType NoteProperty -Name "Source Email Address" -Value $mailbox.'Source Email Address'
                            $mobj | Add-Member -MemberType NoteProperty -Name "Destination Email Address" -Value $mailbox.'Destination Email Address'         
                            $mobj | Add-Member -MemberType NoteProperty -Name "Permission" -Value 'Send As'
                            $mobj | Add-Member -MemberType NoteProperty -Name "User" -Value $sendAs
                            $mobj | Add-Member -MemberType NoteProperty -Name "Status" -Value 'Successful'
                            $mobj | Add-Member -MemberType NoteProperty -Name "Comment" -Value ''
                            $ret += $mobj
                        }      
                    }
                    else
                    {
                        Log-Info "No user is assigned ""Send as"" permission for the source mailbox." -ConsoleInfo $false
                    }
                    Log-Info "Successfully retrieved the ""Send as"" permission of the mailbox ""$($mailbox.'Source Email Address')""." 
                }
                catch
                {
                    $errorMessage = "Failed to retrieve the ""Send as"" permission of the mailbox ""$($mailbox.'Source Email Address')"". Details: $($_.Exception.Message)"
                    Log-Error -Message $errorMessage
                    $mobj = New-Object -TypeName PSCustomObject
                    $mobj | Add-Member -MemberType NoteProperty -Name "Source Email Address" -Value $mailbox.'Source Email Address'
                    $mobj | Add-Member -MemberType NoteProperty -Name "Destination Email Address" -Value $mailbox.'Destination Email Address'
                    $mobj | Add-Member -MemberType NoteProperty -Name "Permission" -Value 'Send As'
                    $mobj | Add-Member -MemberType NoteProperty -Name "User" -Value ''
                    $mobj | Add-Member -MemberType NoteProperty -Name "Status" -Value 'Failed'
                    $mobj | Add-Member -MemberType NoteProperty -Name "Comment" -Value $errorMessage
                    $ret += $mobj
                }

                #GET Send On Behalf
                try
                {
                    Log-Info "Start to retrieve the ""Send on behalf"" permission of the mailbox ""$($mailbox.'Source Email Address')""."      
                    $sendOBList = GetMailboxSendOnBehalf($mailbox.'Source Email Address')                    
                    if($sendOBList)
                    {
                        $hasPermissions = $true
                        foreach($sendOB in $sendOBList)
                        {
                            $mobj = New-Object -TypeName PSCustomObject
                            $mobj | Add-Member -MemberType NoteProperty -Name "Source Email Address" -Value $mailbox.'Source Email Address'
                            $mobj | Add-Member -MemberType NoteProperty -Name "Destination Email Address" -Value $mailbox.'Destination Email Address'
                            $mobj | Add-Member -MemberType NoteProperty -Name "Permission" -Value 'Send On Behalf'
                            $mobj | Add-Member -MemberType NoteProperty -Name "User" -Value $sendOB
                            $mobj | Add-Member -MemberType NoteProperty -Name "Status" -Value 'Successful'
                            $mobj | Add-Member -MemberType NoteProperty -Name "Comment" -Value ''
                            $ret += $mobj
                        }       
                    }
                    else
                    {
                        Log-Info 'No user is assigned "Send on behalf" permission for the source mailbox.' -ConsoleInfo $false
                    }
                    Log-Info "Successfully retrieved the ""Send on behalf"" permission of the mailbox ""$($mailbox.'Source Email Address')""." 
                }
                catch
                {
                    $errorMessage = "Failed to retrieve the ""Send on behalf"" permission of the mailbox ""$($mailbox.MailboxAddress)"". Details: $($_.Exception.Message)"
                    Log-Error -Message $errorMessage
                    $mobj = New-Object -TypeName PSCustomObject
                    $mobj | Add-Member -MemberType NoteProperty -Name "Source Email Address" -Value $mailbox.'Source Email Address'
                    $mobj | Add-Member -MemberType NoteProperty -Name "Destination Email Address" -Value $mailbox.'Destination Email Address'
                    $mobj | Add-Member -MemberType NoteProperty -Name "Permission" -Value 'Send On Behalf'
                    $mobj | Add-Member -MemberType NoteProperty -Name "User" -Value ''
                    $mobj | Add-Member -MemberType NoteProperty -Name "Status" -Value 'Failed'
                    $mobj | Add-Member -MemberType NoteProperty -Name "Comment" -Value $errorMessage
                    $ret += $mobj
                }

                #GET Full Access
                try
                {
                    Log-Info "Start to retrieve the ""Full access"" permission of the mailbox ""$($mailbox.'Source Email Address')""."      
                    $fullAccessList = GetMailboxFullAccess($mailbox.'Source Email Address')
                    if($fullAccessList)
                    {
                        $hasPermissions = $true
                        foreach($fullAccess in $fullAccessList)
                        {
                            $mobj = New-Object -TypeName PSCustomObject
                            $mobj | Add-Member -MemberType NoteProperty -Name "Source Email Address" -Value $mailbox.'Source Email Address'
                            $mobj | Add-Member -MemberType NoteProperty -Name "Destination Email Address" -Value $mailbox.'Destination Email Address'                  
                            $mobj | Add-Member -MemberType NoteProperty -Name "Permission" -Value 'Full Access'
                            $mobj | Add-Member -MemberType NoteProperty -Name "User" -Value $fullAccess
                            $mobj | Add-Member -MemberType NoteProperty -Name "Status" -Value 'Successful'
                            $mobj | Add-Member -MemberType NoteProperty -Name "Comment" -Value ""
                            $ret += $mobj
                        }
                        
                    }
                    else
                    {
                        Log-Info 'No user is assigned "Full access" permission for the source mailbox.' -ConsoleInfo $false      
                    }
                    Log-Info "Successfully retrieved the ""Full access"" permission of the mailbox ""$($mailbox.'Source Email Address')""."
                }
                catch
                {
                    $errorMessage = "Failed to retrieve the ""Full access"" permission of the mailbox ""$($mailbox.'Source Email Address')"". Details: $($_.Exception.Message)"
                    Log-Error -Message $errorMessage
                    $mobj = New-Object -TypeName PSCustomObject
                    $mobj | Add-Member -MemberType NoteProperty -Name "Source Email Address" -Value $mailbox.'Source Email Address'
                    $mobj | Add-Member -MemberType NoteProperty -Name "Destination Email Address" -Value $mailbox.'Destination Email Address'
                    $mobj | Add-Member -MemberType NoteProperty -Name "Permission" -Value 'Full Access'
                    $mobj | Add-Member -MemberType NoteProperty -Name "User" -Value ''
                    $mobj | Add-Member -MemberType NoteProperty -Name "Status" -Value 'Failed'
                    $mobj | Add-Member -MemberType NoteProperty -Name "Comment" -Value $errorMessage
                    $ret += $mobj
                }

                If ($hasPermissions -eq $false)
                {
                    $mobj = New-Object -TypeName PSCustomObject
                    $mobj | Add-Member -MemberType NoteProperty -Name "Source Email Address" -Value $mailbox.'Source Email Address'
                    $mobj | Add-Member -MemberType NoteProperty -Name "Destination Email Address" -Value $mailbox.'Destination Email Address'
                    $mobj | Add-Member -MemberType NoteProperty -Name "Permission" -Value 'All permissions'
                    $mobj | Add-Member -MemberType NoteProperty -Name "User" -Value ''
                    $mobj | Add-Member -MemberType NoteProperty -Name "Status" -Value 'Successful'
                    $mobj | Add-Member -MemberType NoteProperty -Name "Comment" -Value 'The source mailbox does not have any permission.'
                    $ret += $mobj
                }
            }
            else
            {
                $failedMailboxCount = $failedMailboxCount + 1
                $errorMessage = "There is no source or destination email address configured in the `"MailboxMappings.csv`" file."
                Log-Error -Message $errorMessage
                $mobj = New-Object -TypeName PSCustomObject
                $mobj | Add-Member -MemberType NoteProperty -Name "Source Email Address" -Value $mailbox.'Source Email Address'
                $mobj | Add-Member -MemberType NoteProperty -Name "Destination Email Address" -Value $mailbox.'Destination Email Address'
                $mobj | Add-Member -MemberType NoteProperty -Name "Permission" -Value 'All permissions'
                $mobj | Add-Member -MemberType NoteProperty -Name "User" -Value ''
                $mobj | Add-Member -MemberType NoteProperty -Name "Status" -Value 'Failed'
                $mobj | Add-Member -MemberType NoteProperty -Name "Comment" -Value $errorMessage
                $ret += $mobj
            }
        }
        $ret | Export-Csv -Path $reportPath -NoTypeInformation -Encoding UTF8 
    }
    else
    {
        Log-Error -Message "Job failed. The `"MailboxMappings.csv`" file in the $($csvPath) directory is empty."
        exit
    }
}
catch
{
    Log-Error -Message "An error occurred. Details: $($_.Exception.Message)"
    Log-Error -Message "An error occurred. Details: $($_.Exception)" -ConsoleInfo $false
}

Log-Info "failedMailboxCount:$($failedMailboxCount). TotalCount:$($totalCount)" -ConsoleInfo $false
if($failedMailboxCount -eq 0 -and $totalCount -gt 0)
{
    Write-Host "Job finished. You can check the job report in the $($reportPath) directory." -ForegroundColor Green
    Log-Info "Job finished. You can check the job report in the $($reportPath) directory." -ConsoleInfo $false
}
elseif($failedMailboxCount -lt $totalCount)
{
    Write-Host "Job finished with exception. You can check the job report in the $($reportPath) directory and the job logs in the $($logFullPath) directory." -ForegroundColor Yellow
    Log-Warning "Job finished with exception. You can check the job report in the $($reportPath) directory and the job logs in the $($logFullPath) directory." -ConsoleInfo $false
}
else
{
    Write-Host "Job failed. You can check the job report in the $($reportPath) directory and the job logs in the $($logFullPath) directory." -ForegroundColor Red
    Log-Error -Message "Job failed. You can check the job report in the $($reportPath) directory and the job logs in the $($logFullPath) directory." -ConsoleInfo $false
}
# SIG # Begin signature block
# MIIoHgYJKoZIhvcNAQcCoIIoDzCCKAsCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDqwG4kzysKbiAX
# ABOFLQ1I76hV71j3ZKoucDAPmF17yqCCDZowggawMIIEmKADAgECAhAIrUCyYNKc
# TJ9ezam9k67ZMA0GCSqGSIb3DQEBDAUAMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQK
# EwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNV
# BAMTGERpZ2lDZXJ0IFRydXN0ZWQgUm9vdCBHNDAeFw0yMTA0MjkwMDAwMDBaFw0z
# NjA0MjgyMzU5NTlaMGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwg
# SW5jLjFBMD8GA1UEAxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBDb2RlIFNpZ25pbmcg
# UlNBNDA5NiBTSEEzODQgMjAyMSBDQTEwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAw
# ggIKAoICAQDVtC9C0CiteLdd1TlZG7GIQvUzjOs9gZdwxbvEhSYwn6SOaNhc9es0
# JAfhS0/TeEP0F9ce2vnS1WcaUk8OoVf8iJnBkcyBAz5NcCRks43iCH00fUyAVxJr
# Q5qZ8sU7H/Lvy0daE6ZMswEgJfMQ04uy+wjwiuCdCcBlp/qYgEk1hz1RGeiQIXhF
# LqGfLOEYwhrMxe6TSXBCMo/7xuoc82VokaJNTIIRSFJo3hC9FFdd6BgTZcV/sk+F
# LEikVoQ11vkunKoAFdE3/hoGlMJ8yOobMubKwvSnowMOdKWvObarYBLj6Na59zHh
# 3K3kGKDYwSNHR7OhD26jq22YBoMbt2pnLdK9RBqSEIGPsDsJ18ebMlrC/2pgVItJ
# wZPt4bRc4G/rJvmM1bL5OBDm6s6R9b7T+2+TYTRcvJNFKIM2KmYoX7BzzosmJQay
# g9Rc9hUZTO1i4F4z8ujo7AqnsAMrkbI2eb73rQgedaZlzLvjSFDzd5Ea/ttQokbI
# YViY9XwCFjyDKK05huzUtw1T0PhH5nUwjewwk3YUpltLXXRhTT8SkXbev1jLchAp
# QfDVxW0mdmgRQRNYmtwmKwH0iU1Z23jPgUo+QEdfyYFQc4UQIyFZYIpkVMHMIRro
# OBl8ZhzNeDhFMJlP/2NPTLuqDQhTQXxYPUez+rbsjDIJAsxsPAxWEQIDAQABo4IB
# WTCCAVUwEgYDVR0TAQH/BAgwBgEB/wIBADAdBgNVHQ4EFgQUaDfg67Y7+F8Rhvv+
# YXsIiGX0TkIwHwYDVR0jBBgwFoAU7NfjgtJxXWRM3y5nP+e6mK4cD08wDgYDVR0P
# AQH/BAQDAgGGMBMGA1UdJQQMMAoGCCsGAQUFBwMDMHcGCCsGAQUFBwEBBGswaTAk
# BggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNlcnQuY29tMEEGCCsGAQUFBzAC
# hjVodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkUm9v
# dEc0LmNydDBDBgNVHR8EPDA6MDigNqA0hjJodHRwOi8vY3JsMy5kaWdpY2VydC5j
# b20vRGlnaUNlcnRUcnVzdGVkUm9vdEc0LmNybDAcBgNVHSAEFTATMAcGBWeBDAED
# MAgGBmeBDAEEATANBgkqhkiG9w0BAQwFAAOCAgEAOiNEPY0Idu6PvDqZ01bgAhql
# +Eg08yy25nRm95RysQDKr2wwJxMSnpBEn0v9nqN8JtU3vDpdSG2V1T9J9Ce7FoFF
# UP2cvbaF4HZ+N3HLIvdaqpDP9ZNq4+sg0dVQeYiaiorBtr2hSBh+3NiAGhEZGM1h
# mYFW9snjdufE5BtfQ/g+lP92OT2e1JnPSt0o618moZVYSNUa/tcnP/2Q0XaG3Ryw
# YFzzDaju4ImhvTnhOE7abrs2nfvlIVNaw8rpavGiPttDuDPITzgUkpn13c5Ubdld
# AhQfQDN8A+KVssIhdXNSy0bYxDQcoqVLjc1vdjcshT8azibpGL6QB7BDf5WIIIJw
# 8MzK7/0pNVwfiThV9zeKiwmhywvpMRr/LhlcOXHhvpynCgbWJme3kuZOX956rEnP
# LqR0kq3bPKSchh/jwVYbKyP/j7XqiHtwa+aguv06P0WmxOgWkVKLQcBIhEuWTatE
# QOON8BUozu3xGFYHKi8QxAwIZDwzj64ojDzLj4gLDb879M4ee47vtevLt/B3E+bn
# KD+sEq6lLyJsQfmCXBVmzGwOysWGw/YmMwwHS6DTBwJqakAwSEs0qFEgu60bhQji
# WQ1tygVQK+pKHJ6l/aCnHwZ05/LWUpD9r4VIIflXO7ScA+2GRfS0YW6/aOImYIbq
# yK+p/pQd52MbOoZWeE4wggbiMIIEyqADAgECAhAPc9sqd/BkUUsWn0FQMB0UMA0G
# CSqGSIb3DQEBCwUAMGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwg
# SW5jLjFBMD8GA1UEAxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBDb2RlIFNpZ25pbmcg
# UlNBNDA5NiBTSEEzODQgMjAyMSBDQTEwHhcNMjMxMTAzMDAwMDAwWhcNMjYxMTE0
# MjM1OTU5WjBqMQswCQYDVQQGEwJVUzETMBEGA1UECBMKTmV3IEplcnNleTEUMBIG
# A1UEBxMLSmVyc2V5IENpdHkxFzAVBgNVBAoTDkF2ZVBvaW50LCBJbmMuMRcwFQYD
# VQQDEw5BdmVQb2ludCwgSW5jLjCCAaIwDQYJKoZIhvcNAQEBBQADggGPADCCAYoC
# ggGBAOEW7Ii2pvR9/732eojqygVHkWY2HMdaefS7g4Z4EOt6ABrXYcTFvIMax1DN
# 7ZCbfarSe6B0jsXnrNbhTZKJiphzbLAIs4NOi4EMxdWzDbc8oZqByMX77NxSiaR3
# PhqFGI99Utr9NUIBsruS6AccQ6CkP2nNejixv6BrsGJbUDrgz6A66x7V4WhYa6df
# qmMU8EucSyjcZB2A4h21H+jURe95N1SZThOw6vfFKn5JPnKvGTCuH0u19xi8d90j
# ZItOntrR92wzFG2jSd4Z3DeKyvIDWxGGqaDqloA7thXNGN/URNqTZfeXdsF6uUU2
# IojpWh8gYBTnu9i8cM9PVDOB420h5JaV+1XLO8m10LtnYBSWZWgUHpcTq7Suwbah
# 0/yiur0ltzR13dQ0wk2Xe1i/G8PlKw4IlyqESqizT3YxUGlqwcojIAYwaGBtATTf
# kCKq32rornXSmCqfrQICoA8dR7pry8hl/JloSD/+riT62F8r8mQTlLUw5xNiqBqE
# kIQvuQIDAQABo4ICAzCCAf8wHwYDVR0jBBgwFoAUaDfg67Y7+F8Rhvv+YXsIiGX0
# TkIwHQYDVR0OBBYEFJxiV1oIFotUW4UTNkwFNyJScORPMD4GA1UdIAQ3MDUwMwYG
# Z4EMAQQBMCkwJwYIKwYBBQUHAgEWG2h0dHA6Ly93d3cuZGlnaWNlcnQuY29tL0NQ
# UzAOBgNVHQ8BAf8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwgbUGA1UdHwSB
# rTCBqjBToFGgT4ZNaHR0cDovL2NybDMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0VHJ1
# c3RlZEc0Q29kZVNpZ25pbmdSU0E0MDk2U0hBMzg0MjAyMUNBMS5jcmwwU6BRoE+G
# TWh0dHA6Ly9jcmw0LmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydFRydXN0ZWRHNENvZGVT
# aWduaW5nUlNBNDA5NlNIQTM4NDIwMjFDQTEuY3JsMIGUBggrBgEFBQcBAQSBhzCB
# hDAkBggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNlcnQuY29tMFwGCCsGAQUF
# BzAChlBodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVk
# RzRDb2RlU2lnbmluZ1JTQTQwOTZTSEEzODQyMDIxQ0ExLmNydDAJBgNVHRMEAjAA
# MA0GCSqGSIb3DQEBCwUAA4ICAQDE9SZRwvtvpHrw4OjJ1AKL0aabKlOUkxidOjEC
# wrWr4yFKJdHWHpouUFTye7M8gQS4FQDQqD4ys7a1joCQVd+WEiQIyy0TzJXxT7US
# tkhg8lD41cT7i857dgnSrX7Prp0Es/xFBhEKR0fMs3Sj20+qcnJNTB4TA9CPnUd4
# UL1Ve/bqsr5lVZgoPp6wbs0lXjsTEfzrio++T4ssc42eTxfv6YZgTmdrPEQNqLUa
# hQuQ0x5j8lVBBtt5PrC7TikkVB/GBZ+01EJrUQvcX3arZky1tviINBQ3EXRhyGkx
# zSz6Vk9NxwJVkdavIUkdDuUuqNVqp2a3Zsv2L3mwlr0UnKMgpBiPnxgC9u6e5tjR
# +plDe3fmD20XQTt/p61FueC7w92HC6YizDrynRX58h6KuRv2j/u2yZU3nipaiGlz
# 8jURf2ySxZXI2QG228Nfsg4y1Z61tPfYb4kcqTfVcaxh7azpP6BU33dkIyC7dmv4
# q3PueRcSyweKjqlQqeswnTeBS3+met1BbjkMdJJzqbIu5WONTBIHHH1RGsQYPn8i
# ms3pE0GhGl9c1r1BpufehQwSjCZRc/vHrHUOQyNimVKoOtls5UAxU5FXO3PKaHPO
# M6dFS1b+EF6drXV0M9/KdJVyyP4EK6CJQVt7RrQBRSSdQCKCYJ63VUF5amRuzY0s
# EqLoRTGCGdowghnWAgEBMH0waTELMAkGA1UEBhMCVVMxFzAVBgNVBAoTDkRpZ2lD
# ZXJ0LCBJbmMuMUEwPwYDVQQDEzhEaWdpQ2VydCBUcnVzdGVkIEc0IENvZGUgU2ln
# bmluZyBSU0E0MDk2IFNIQTM4NCAyMDIxIENBMQIQD3PbKnfwZFFLFp9BUDAdFDAN
# BglghkgBZQMEAgEFAKB8MBAGCisGAQQBgjcCAQwxAjAAMBkGCSqGSIb3DQEJAzEM
# BgorBgEEAYI3AgEEMBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMC8GCSqG
# SIb3DQEJBDEiBCB4Oq5yIk1NFsHIrx79djMOmhHxCkMlkmHI0AaNl+KUwjANBgkq
# hkiG9w0BAQEFAASCAYChdZzP01FkVeuqqym3T2KdqZEBcrhPKaYsjxpiUs2PCz0D
# QfNb5sT71y1AJDvA7yI3Ywgup4rTXF4VIWpI4QsA+Z6pXq8HBHglM29CBlQDcePE
# NzxRNJ6dqosVkcZ5Vh2RjvOIxFQTpGlLLHS1QicGNOtAsnAF1GroP4fZM5NO/Si/
# 3S3mQVZvLZzY23+BmyPXrcuUfGpLRPCPioa3+1vQ78gbhRTU9Cmdhtxb0kucxukE
# qIHB29qqkvAij+N5V+I0FNaBwPvISbPkjxo6oPexxuGZdbWkJiHRT0M7F0AIzTZ9
# BRgMIJGHS9hwD3Xf/jO2sXaGdWeyj9+lMYZt1kHqFpYzsFmWZG5wdjrJt9lsTL4u
# DCQW9JzUsN9MFv6mdWfw9fLsTH0iaqQJ6pb2b/4dGLMxMGhGqoUfetZcnqeZF0uj
# ug87JwjHWQ/GmDp3N+FWSj303zsP9q9JQytKLZoGhbqhinEreynNPM+X6Rk555IF
# asn0Fb2E0HAY5LyM6TShghcwMIIXLAYKKwYBBAGCNwMDATGCFxwwghcYBgkqhkiG
# 9w0BBwKgghcJMIIXBQIBAzEPMA0GCWCGSAFlAwQCAQUAMGgGCyqGSIb3DQEJEAEE
# oFkEVzBVAgEBBglghkgBhv1sBwEwITAJBgUrDgMCGgUABBTmjlLbIM3N8ODJrAZL
# 68AqLQBEaAIRAOvAMVLOnTheHttoDBbp+G8YDzIwMjQwODA4MDUyMzUyWqCCEwkw
# ggbCMIIEqqADAgECAhAFRK/zlJ0IOaa/2z9f5WEWMA0GCSqGSIb3DQEBCwUAMGMx
# CzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjE7MDkGA1UEAxMy
# RGlnaUNlcnQgVHJ1c3RlZCBHNCBSU0E0MDk2IFNIQTI1NiBUaW1lU3RhbXBpbmcg
# Q0EwHhcNMjMwNzE0MDAwMDAwWhcNMzQxMDEzMjM1OTU5WjBIMQswCQYDVQQGEwJV
# UzEXMBUGA1UEChMORGlnaUNlcnQsIEluYy4xIDAeBgNVBAMTF0RpZ2lDZXJ0IFRp
# bWVzdGFtcCAyMDIzMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAo1NF
# hx2DjlusPlSzI+DPn9fl0uddoQ4J3C9Io5d6OyqcZ9xiFVjBqZMRp82qsmrdECmK
# HmJjadNYnDVxvzqX65RQjxwg6seaOy+WZuNp52n+W8PWKyAcwZeUtKVQgfLPywem
# MGjKg0La/H8JJJSkghraarrYO8pd3hkYhftF6g1hbJ3+cV7EBpo88MUueQ8bZlLj
# yNY+X9pD04T10Mf2SC1eRXWWdf7dEKEbg8G45lKVtUfXeCk5a+B4WZfjRCtK1ZXO
# 7wgX6oJkTf8j48qG7rSkIWRw69XloNpjsy7pBe6q9iT1HbybHLK3X9/w7nZ9MZll
# R1WdSiQvrCuXvp/k/XtzPjLuUjT71Lvr1KAsNJvj3m5kGQc3AZEPHLVRzapMZoOI
# aGK7vEEbeBlt5NkP4FhB+9ixLOFRr7StFQYU6mIIE9NpHnxkTZ0P387RXoyqq1AV
# ybPKvNfEO2hEo6U7Qv1zfe7dCv95NBB+plwKWEwAPoVpdceDZNZ1zY8SdlalJPrX
# xGshuugfNJgvOuprAbD3+yqG7HtSOKmYCaFxsmxxrz64b5bV4RAT/mFHCoz+8LbH
# 1cfebCTwv0KCyqBxPZySkwS0aXAnDU+3tTbRyV8IpHCj7ArxES5k4MsiK8rxKBMh
# SVF+BmbTO77665E42FEHypS34lCh8zrTioPLQHsCAwEAAaOCAYswggGHMA4GA1Ud
# DwEB/wQEAwIHgDAMBgNVHRMBAf8EAjAAMBYGA1UdJQEB/wQMMAoGCCsGAQUFBwMI
# MCAGA1UdIAQZMBcwCAYGZ4EMAQQCMAsGCWCGSAGG/WwHATAfBgNVHSMEGDAWgBS6
# FtltTYUvcyl2mi91jGogj57IbzAdBgNVHQ4EFgQUpbbvE+fvzdBkodVWqWUxo97V
# 40kwWgYDVR0fBFMwUTBPoE2gS4ZJaHR0cDovL2NybDMuZGlnaWNlcnQuY29tL0Rp
# Z2lDZXJ0VHJ1c3RlZEc0UlNBNDA5NlNIQTI1NlRpbWVTdGFtcGluZ0NBLmNybDCB
# kAYIKwYBBQUHAQEEgYMwgYAwJAYIKwYBBQUHMAGGGGh0dHA6Ly9vY3NwLmRpZ2lj
# ZXJ0LmNvbTBYBggrBgEFBQcwAoZMaHR0cDovL2NhY2VydHMuZGlnaWNlcnQuY29t
# L0RpZ2lDZXJ0VHJ1c3RlZEc0UlNBNDA5NlNIQTI1NlRpbWVTdGFtcGluZ0NBLmNy
# dDANBgkqhkiG9w0BAQsFAAOCAgEAgRrW3qCptZgXvHCNT4o8aJzYJf/LLOTN6l0i
# kuyMIgKpuM+AqNnn48XtJoKKcS8Y3U623mzX4WCcK+3tPUiOuGu6fF29wmE3aEl3
# o+uQqhLXJ4Xzjh6S2sJAOJ9dyKAuJXglnSoFeoQpmLZXeY/bJlYrsPOnvTcM2Jh2
# T1a5UsK2nTipgedtQVyMadG5K8TGe8+c+njikxp2oml101DkRBK+IA2eqUTQ+OVJ
# dwhaIcW0z5iVGlS6ubzBaRm6zxbygzc0brBBJt3eWpdPM43UjXd9dUWhpVgmagNF
# 3tlQtVCMr1a9TMXhRsUo063nQwBw3syYnhmJA+rUkTfvTVLzyWAhxFZH7doRS4wy
# w4jmWOK22z75X7BC1o/jF5HRqsBV44a/rCcsQdCaM0qoNtS5cpZ+l3k4SF/Kwtw9
# Mt911jZnWon49qfH5U81PAC9vpwqbHkB3NpE5jreODsHXjlY9HxzMVWggBHLFAx+
# rrz+pOt5Zapo1iLKO+uagjVXKBbLafIymrLS2Dq4sUaGa7oX/cR3bBVsrquvczro
# SUa31X/MtjjA2Owc9bahuEMs305MfR5ocMB3CtQC4Fxguyj/OOVSWtasFyIjTvTs
# 0xf7UGv/B3cfcZdEQcm4RtNsMnxYL2dHZeUbc7aZ+WssBkbvQR7w8F/g29mtkIBE
# r4AQQYowggauMIIElqADAgECAhAHNje3JFR82Ees/ShmKl5bMA0GCSqGSIb3DQEB
# CwUAMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMxGTAXBgNV
# BAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lDZXJ0IFRydXN0ZWQg
# Um9vdCBHNDAeFw0yMjAzMjMwMDAwMDBaFw0zNzAzMjIyMzU5NTlaMGMxCzAJBgNV
# BAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjE7MDkGA1UEAxMyRGlnaUNl
# cnQgVHJ1c3RlZCBHNCBSU0E0MDk2IFNIQTI1NiBUaW1lU3RhbXBpbmcgQ0EwggIi
# MA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQDGhjUGSbPBPXJJUVXHJQPE8pE3
# qZdRodbSg9GeTKJtoLDMg/la9hGhRBVCX6SI82j6ffOciQt/nR+eDzMfUBMLJnOW
# bfhXqAJ9/UO0hNoR8XOxs+4rgISKIhjf69o9xBd/qxkrPkLcZ47qUT3w1lbU5ygt
# 69OxtXXnHwZljZQp09nsad/ZkIdGAHvbREGJ3HxqV3rwN3mfXazL6IRktFLydkf3
# YYMZ3V+0VAshaG43IbtArF+y3kp9zvU5EmfvDqVjbOSmxR3NNg1c1eYbqMFkdECn
# wHLFuk4fsbVYTXn+149zk6wsOeKlSNbwsDETqVcplicu9Yemj052FVUmcJgmf6Aa
# RyBD40NjgHt1biclkJg6OBGz9vae5jtb7IHeIhTZgirHkr+g3uM+onP65x9abJTy
# UpURK1h0QCirc0PO30qhHGs4xSnzyqqWc0Jon7ZGs506o9UD4L/wojzKQtwYSH8U
# NM/STKvvmz3+DrhkKvp1KCRB7UK/BZxmSVJQ9FHzNklNiyDSLFc1eSuo80VgvCON
# WPfcYd6T/jnA+bIwpUzX6ZhKWD7TA4j+s4/TXkt2ElGTyYwMO1uKIqjBJgj5FBAS
# A31fI7tk42PgpuE+9sJ0sj8eCXbsq11GdeJgo1gJASgADoRU7s7pXcheMBK9Rp61
# 03a50g5rmQzSM7TNsQIDAQABo4IBXTCCAVkwEgYDVR0TAQH/BAgwBgEB/wIBADAd
# BgNVHQ4EFgQUuhbZbU2FL3MpdpovdYxqII+eyG8wHwYDVR0jBBgwFoAU7NfjgtJx
# XWRM3y5nP+e6mK4cD08wDgYDVR0PAQH/BAQDAgGGMBMGA1UdJQQMMAoGCCsGAQUF
# BwMIMHcGCCsGAQUFBwEBBGswaTAkBggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGln
# aWNlcnQuY29tMEEGCCsGAQUFBzAChjVodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5j
# b20vRGlnaUNlcnRUcnVzdGVkUm9vdEc0LmNydDBDBgNVHR8EPDA6MDigNqA0hjJo
# dHRwOi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkUm9vdEc0LmNy
# bDAgBgNVHSAEGTAXMAgGBmeBDAEEAjALBglghkgBhv1sBwEwDQYJKoZIhvcNAQEL
# BQADggIBAH1ZjsCTtm+YqUQiAX5m1tghQuGwGC4QTRPPMFPOvxj7x1Bd4ksp+3CK
# Daopafxpwc8dB+k+YMjYC+VcW9dth/qEICU0MWfNthKWb8RQTGIdDAiCqBa9qVbP
# FXONASIlzpVpP0d3+3J0FNf/q0+KLHqrhc1DX+1gtqpPkWaeLJ7giqzl/Yy8ZCaH
# bJK9nXzQcAp876i8dU+6WvepELJd6f8oVInw1YpxdmXazPByoyP6wCeCRK6ZJxur
# JB4mwbfeKuv2nrF5mYGjVoarCkXJ38SNoOeY+/umnXKvxMfBwWpx2cYTgAnEtp/N
# h4cku0+jSbl3ZpHxcpzpSwJSpzd+k1OsOx0ISQ+UzTl63f8lY5knLD0/a6fxZsNB
# zU+2QJshIUDQtxMkzdwdeDrknq3lNHGS1yZr5Dhzq6YBT70/O3itTK37xJV77Qpf
# MzmHQXh6OOmc4d0j/R0o08f56PGYX/sr2H7yRp11LB4nLCbbbxV7HhmLNriT1Oby
# F5lZynDwN7+YAN8gFk8n+2BnFqFmut1VwDophrCYoCvtlUG3OtUVmDG0YgkPCr2B
# 2RP+v6TR81fZvAT6gt4y3wSJ8ADNXcL50CN/AAvkdgIm2fBldkKmKYcJRyvmfxqk
# hQ/8mJb2VVQrH4D6wPIOK+XW+6kvRBVK5xMOHds3OBqhK/bt1nz8MIIFjTCCBHWg
# AwIBAgIQDpsYjvnQLefv21DiCEAYWjANBgkqhkiG9w0BAQwFADBlMQswCQYDVQQG
# EwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNl
# cnQuY29tMSQwIgYDVQQDExtEaWdpQ2VydCBBc3N1cmVkIElEIFJvb3QgQ0EwHhcN
# MjIwODAxMDAwMDAwWhcNMzExMTA5MjM1OTU5WjBiMQswCQYDVQQGEwJVUzEVMBMG
# A1UEChMMRGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMSEw
# HwYDVQQDExhEaWdpQ2VydCBUcnVzdGVkIFJvb3QgRzQwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQC/5pBzaN675F1KPDAiMGkz7MKnJS7JIT3yithZwuEp
# pz1Yq3aaza57G4QNxDAf8xukOBbrVsaXbR2rsnnyyhHS5F/WBTxSD1Ifxp4VpX6+
# n6lXFllVcq9ok3DCsrp1mWpzMpTREEQQLt+C8weE5nQ7bXHiLQwb7iDVySAdYykt
# zuxeTsiT+CFhmzTrBcZe7FsavOvJz82sNEBfsXpm7nfISKhmV1efVFiODCu3T6cw
# 2Vbuyntd463JT17lNecxy9qTXtyOj4DatpGYQJB5w3jHtrHEtWoYOAMQjdjUN6Qu
# BX2I9YI+EJFwq1WCQTLX2wRzKm6RAXwhTNS8rhsDdV14Ztk6MUSaM0C/CNdaSaTC
# 5qmgZ92kJ7yhTzm1EVgX9yRcRo9k98FpiHaYdj1ZXUJ2h4mXaXpI8OCiEhtmmnTK
# 3kse5w5jrubU75KSOp493ADkRSWJtppEGSt+wJS00mFt6zPZxd9LBADMfRyVw4/3
# IbKyEbe7f/LVjHAsQWCqsWMYRJUadmJ+9oCw++hkpjPRiQfhvbfmQ6QYuKZ3AeEP
# lAwhHbJUKSWJbOUOUlFHdL4mrLZBdd56rF+NP8m800ERElvlEFDrMcXKchYiCd98
# THU/Y+whX8QgUWtvsauGi0/C1kVfnSD8oR7FwI+isX4KJpn15GkvmB0t9dmpsh3l
# GwIDAQABo4IBOjCCATYwDwYDVR0TAQH/BAUwAwEB/zAdBgNVHQ4EFgQU7NfjgtJx
# XWRM3y5nP+e6mK4cD08wHwYDVR0jBBgwFoAUReuir/SSy4IxLVGLp6chnfNtyA8w
# DgYDVR0PAQH/BAQDAgGGMHkGCCsGAQUFBwEBBG0wazAkBggrBgEFBQcwAYYYaHR0
# cDovL29jc3AuZGlnaWNlcnQuY29tMEMGCCsGAQUFBzAChjdodHRwOi8vY2FjZXJ0
# cy5kaWdpY2VydC5jb20vRGlnaUNlcnRBc3N1cmVkSURSb290Q0EuY3J0MEUGA1Ud
# HwQ+MDwwOqA4oDaGNGh0dHA6Ly9jcmwzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydEFz
# c3VyZWRJRFJvb3RDQS5jcmwwEQYDVR0gBAowCDAGBgRVHSAAMA0GCSqGSIb3DQEB
# DAUAA4IBAQBwoL9DXFXnOF+go3QbPbYW1/e/Vwe9mqyhhyzshV6pGrsi+IcaaVQi
# 7aSId229GhT0E0p6Ly23OO/0/4C5+KH38nLeJLxSA8hO0Cre+i1Wz/n096wwepqL
# sl7Uz9FDRJtDIeuWcqFItJnLnU+nBgMTdydE1Od/6Fmo8L8vC6bp8jQ87PcDx4eo
# 0kxAGTVGamlUsLihVo7spNU96LHc/RzY9HdaXFSMb++hUD38dglohJ9vytsgjTVg
# HAIDyyCwrFigDkBjxZgiwbJZ9VVrzyerbHbObyMt9H5xaiNrIv8SuFQtJ37YOtnw
# toeW/VvRXKwYw02fc7cBqZ9Xql4o4rmUMYIDdjCCA3ICAQEwdzBjMQswCQYDVQQG
# EwJVUzEXMBUGA1UEChMORGlnaUNlcnQsIEluYy4xOzA5BgNVBAMTMkRpZ2lDZXJ0
# IFRydXN0ZWQgRzQgUlNBNDA5NiBTSEEyNTYgVGltZVN0YW1waW5nIENBAhAFRK/z
# lJ0IOaa/2z9f5WEWMA0GCWCGSAFlAwQCAQUAoIHRMBoGCSqGSIb3DQEJAzENBgsq
# hkiG9w0BCRABBDAcBgkqhkiG9w0BCQUxDxcNMjQwODA4MDUyMzUyWjArBgsqhkiG
# 9w0BCRACDDEcMBowGDAWBBRm8CsywsLJD4JdzqqKycZPGZzPQDAvBgkqhkiG9w0B
# CQQxIgQghy5vujQGpscmkpwsKkwAZxYFPsC4twtFSkTwdhbzlV4wNwYLKoZIhvcN
# AQkQAi8xKDAmMCQwIgQg0vbkbe10IszR1EBXaEE2b4KK2lWarjMWr00amtQMeCgw
# DQYJKoZIhvcNAQEBBQAEggIANE31Xs4DiHQ5GNECaoQL4TlR+ROHRuWQl6cE9vgU
# lkNX6sde3+Cro9dZaBYs5igFGgfm/oPUk6eyO+FFOZAXfACEUcSb37O4EOGn6Y3w
# SUdTwAoCYKihao9BW/2YL2nweinAMLsdnsh/lT0wMgvRbpECXyWpjN9/BdUN+AEM
# Q6htgiCEy7wuvCqV80v2Tkb/NjVD6HaSCYxHw6SWjLzHKDV8yNLEmShEC/s++pbV
# 9Vg02mjlQ+XByr8f769+hGd1/dYmAyJeXaJ6zBc7d71OC4BQP7dW3zhumwXbb6on
# bcGDhIdhYKLyIht1M2pGlwHt+AcMLT/Te9IiFGG95ov/0WKNxqd7bHhAnm6LzInt
# Yd5UNDuuYp7kmK2iCy7/ntX6MgshcAxZTWFsVwoR7DeZhQ7mjMVuX3hs06wDkn07
# utj7zp7mD5rJo/lQzeiyHP3on7NoEOBvTddinjpWlNga0bYFTUNCw5WOOKZ/e1BK
# dWh1Hw4UAj1fD+JHSQl4KPMUIuHdK5LaGFHRuuOKe4hKvI0nR/IR0Sj/g4r3n0X3
# o/1h3GXzxb6l+9Aorw16VbRAFEp4wOg2fsVr+bwI9nyViNI48h8rb4RGEUlIKZej
# mchW4qWnb7x7LtLWmS2YYLVI8U0ajJUDkVtczfxcgA29wKVPe2+qkcvhqQIwqfzP
# 3ec=
# SIG # End signature block
