<# /********************************************************************
 *
 *  PROPRIETARY and CONFIDENTIAL
 *
 *  This file is licensed from, and is a trade secret of:
 *
 *                   AvePoint, Inc.
 *                   525 Washington Blvd, Suite 1400
 *                   Jersey City, NJ 07310
 *                   United States of America
 *                   Telephone: +1-201-793-1111
 *                   WWW: www.avepoint.com
 *
 *  Refer to your License Agreement for restrictions on use,
 *  duplication, or disclosure.
 *
 *  RESTRICTED RIGHTS LEGEND
 *
 *  Use, duplication, or disclosure by the Government is
 *  subject to restrictions as set forth in subdivision
 *  (c)(1)(ii) of the Rights in Technical Data and Computer
 *  Software clause at DFARS 252.227-7013 (Oct. 1988) and
 *  FAR 52.227-19 (C) (June 1987).
 *
 *  Copyright © 2017-2026 AvePoint® Inc. All Rights Reserved.
 *
 *  Unpublished - All rights reserved under the copyright laws of the United States.
 */ #>
$Invocation = (Get-Variable MyInvocation).Value
$CurrentPath = (Get-Item $invocation.MyCommand.Path).Directory.FullName
."$CurrentPath\Common\LogFuncs.ps1"
."$CurrentPath\Common\CommonFuncs.ps1"
$csvUserMappingPath="$currentPath\UserOrDomainMappings.csv"
$csvSharedContent =@()
$userMappings =@{}
$domainMappings =@{}
$timestamp = Get-Date -UFormat %Y%m%d%H%M%S
$logName="RestoreSharedFullAccess_$timestamp.log";
try
{ 
 Log-Initialize -Path "$CurrentPath\Logs" -Name $logName
}
catch
{
  Write-Error "Failed to initialize the logs. Reason:$($_.Exception.Message)"
  exit
}
if (test-path $csvUserMappingPath)
{
  $csvUserDomainContent= Import-Csv $csvUserMappingPath
  foreach($temp in $csvUserDomainContent)
  {
     if($temp.Type -eq 'User')
     {
       if(!$userMappings.ContainsKey($temp.Source.ToLower().Trim()))
       {
          $userMappings.Add($temp.Source.ToLower().Trim(),$temp.Destination.ToLower().Trim())
       }
     }
     else
     {
       if(!$domainMappings.ContainsKey($temp.Source.ToLower().Trim()))
       {
          $domainMappings.Add($temp.Source.ToLower().Trim(),$temp.Destination.ToLower().Trim())
       }
     }
  }
}
else
{
   Log-Error "Failed to retrieve the UserOrDomainMappings.csv file in the $($csvUserMappingPath) directory."
   exit
}
$importFile =''
$first='true'
do
 {
    if($first)
    {
      $importFile = Read-Host -Prompt "Enter the path of the SharedMailboxPermissions.csv file"
      $first=''
    }
    else
    {
      Log-Error "The path of the SharedMailboxPermissions.csv file is invalid."
      $importFile = Read-Host -Prompt "Enter the valid path of the SharedMailboxPermissions.csv file"
    }
 }
until (test-path $importFile)
if (test-path $importFile)
{
   Log-Debug "SharedMailboxPermissions file path:$($importFile)"
}
else
{
   Log-Error "Failed to retrieve the SharedMailboxPermissions.csv file."
   exit
}
$csvSharedContent= Import-Csv $importFile
Process-Module -ModuleName 'Msal.ps'
Process-Module -ModuleName 'ExchangeOnlineManagement'
$EWSDLL = "$CurrentPath\Common\Assembly\Microsoft.Exchange.WebServices.dll"
Import-Module $EWSDLL
$Cred = Get-Credential -Message "Enter the username and password of the destination service account."
$Script:ErrorActionPreference = "Stop"
$AppClientId="d3590ed6-52b3-4102-aeff-aad2292ab01c"
$delegateMapping=@{}
$reportPath="$CurrentPath\Report_SharedMailboxPermission_$timestamp.csv"
$result=@()
$connectEx=$false
function GetUserFromMapping([string]$sourceAddress)
{
  try
  {
   $sourceAddress=$sourceAddress.ToLower().Trim()
    if($userMappings -and $userMappings.ContainsKey($sourceAddress))
    {
      return $userMappings[$sourceAddress]
    }
    else
    {
        $domain=  $sourceAddress.Substring($sourceAddress.LastIndexOf('@')+1).ToLower().Trim()
        if($domainMappings -and $domainMappings.ContainsKey($domain))
       {
          $user=$sourceAddress.Substring(0,$sourceAddress.LastIndexOf('@')+1)+$domainMappings[$domain]
          return $user
       }
     }
   }
   catch
   {
     Log-Warning "Failed to get user from mappings. Original: $($sourceAddress). Reason:$($_.Exception.Message)" -ConsoleInfo $false
     return ''
   }
   return ''
}
try
{
    [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12
    $TenantId =  $Cred.UserName.Substring($Cred.UserName.LastIndexOf('@')+1)
    Log-Debug "TenantId:$($TenantId). JobId:$($timestamp)"
    $EwsToken= Get-EWSToken -Credential $Cred -TenantId   $TenantId
    if($EwsToken -eq $null)
    {
       Log-Error -Message "Failed to migrate the permissions of shared mailboxes. Reason: Failed to retrieve the Microsoft Authentication Library token."
       exit
    }
    $service= Get-Service -EwsToken  $EwsToken
    if($service -eq $null)
    {
       Log-Error -Message "Failed to migrate the permissions of shared mailboxes. The auto-discover service is unavailable."
       exit
    }
    Log-Debug "Start to connect Exchange Online with the user $($Cred.UserName)"
    Connect-ExchangeOnline -Credential $Cred
    $connectEx=$true
    Log-Info "Successfully connected to the Exchange Online."
    $hasNoError=$true
    $count=0
    foreach($info in $csvSharedContent)
    {
      $count=$count+1
      Log-Debug "Start to process the shared mailbox $($info.DestinationMailbox). Current Count:$($count)"
      try
      {
         if($info.Status -eq 'Failed')
         {
            $mobj = New-Object -TypeName PSCustomObject
            $mobj | Add-Member -MemberType NoteProperty -Name "SourceMailbox" -Value $info.SourceMailbox.ToLower()
            $mobj | Add-Member -MemberType NoteProperty -Name "DestinationMailbox" -Value $info.DestinationMailbox.ToLower()  
            $mobj | Add-Member -MemberType NoteProperty -Name "SourceUser" -Value  ''
            $mobj | Add-Member -MemberType NoteProperty -Name "DestinationUser" -Value  ''
            $mobj | Add-Member -MemberType NoteProperty -Name "AutoMapping" -Value ''
            $mobj | Add-Member -MemberType NoteProperty -Name "Status" -Value 'Failed'
            $mobj | Add-Member -MemberType NoteProperty -Name "Comment" -Value $info.Comment
            $result += $mobj
            $hasNoError=$false
            continue
         }
         $permissionResult = Get-MailboxPermission -Identity $info.DestinationMailbox -ErrorAction Stop
         $Source_AutoMapping= $addressArrary=$info.'Users-With-AutoMapping'.Split(";",[StringSplitOptions]::RemoveEmptyEntries)
         $Source_Not_AutoMapping= $addressArrary=$info.'Users-Without-AutoMapping'.Split(";",[StringSplitOptions]::RemoveEmptyEntries)
         $users_AutoMapping=''
         $users_Not_AutoMapping=''
         foreach($tempPermission in  $permissionResult)
         {
           [string]$accessRights=$tempPermission.AccessRights
           if($accessRights -eq 'FullAccess')
           {
             if($tempPermission.User -eq 'NT AUTHORITY\SELF' -or  $tempPermission.User -eq 'NT-AUTORIT腡\\SELBST' -or $tempPermission.IsInherited)
             {
              
               continue
             }
             $tempUser=$tempPermission.User.ToLower()
             $deletegates=@()
             if($delegateMapping.ContainsKey($tempUser))
             {
               $deletegates=$delegateMapping[$tempUser]
              if($deletegates -eq 'NeedNewService')
              {
                 Log-Warning "Maybe a mail user, skip it. User:$($tempUser)" -ConsoleInfo $false
                 continue
              }
             }
             else
             {
               $deletegates=Get-SharedDelegates -Service $service -Mailbox $tempUser
               if($deletegates -eq 'NeedNewService')
               {
                 $service= Get-Service -EwsToken  $EwsToken
                 $delegateMapping.Add($tempUser,$deletegates) 
                 Log-Warning "Maybe a mail user, skip it. User:$($tempUser)" -ConsoleInfo $false
                 continue
               }
               $delegateMapping.Add($tempUser,$deletegates) 
             }
             $autoMapping=$false
             if($deletegates -ne $null -and $deletegates.Contains($info.DestinationMailbox.ToLower()))
             {
                 $users_AutoMapping+=$tempUser+';'
             }
             else
             {
                 $users_Not_AutoMapping+=$tempUser+';'
             }
           }
         }
         Log-Info "Shared:$($info.DestinationMailbox). AutoMapping. True:$($users_AutoMapping). False:$($users_Not_AutoMapping)" -ConsoleInfo $false
         Log-Info "Successfully retrieved the delegates of the shared mailbox $($info.DestinationMailbox)"
          #Process AutoMapping is true in source
         foreach($tempUser in $Source_AutoMapping)
         {
            $tempUser=$tempUser.ToLower().Trim()
            Log-Debug "[Trace]Begin to process user:$($tempUser). Auto-Mapping: True." -ConsoleInfo $false
            $mappedUser= GetUserFromMapping($tempUser);
            $mobj = New-Object -TypeName PSCustomObject
            $mobj | Add-Member -MemberType NoteProperty -Name "SourceMailbox" -Value $info.SourceMailbox.ToLower()
            $mobj | Add-Member -MemberType NoteProperty -Name "DestinationMailbox" -Value $info.DestinationMailbox.ToLower()  
            $mobj | Add-Member -MemberType NoteProperty -Name "SourceUser" -Value  $tempUser
            $mobj | Add-Member -MemberType NoteProperty -Name "DestinationUser" -Value  $mappedUser
            $mobj | Add-Member -MemberType NoteProperty -Name "AutoMapping" -Value 'True'
           if($mappedUser -ne '')
           { 
             if($users_AutoMapping.Contains($mappedUser))
             {
                #This user has correct automapping property on destination, skip it.
                Log-Debug "[Trace]Skip due to same property. User:$($tempUser). Auto-Mapping: True." -ConsoleInfo $false
                $mobj | Add-Member -MemberType NoteProperty -Name "Status" -Value 'Skipped'
                $mobj | Add-Member -MemberType NoteProperty -Name "Comment" -Value 'The auto-mapping property is consistent.'
             }
             elseif($users_Not_AutoMapping.Contains($mappedUser))
             {
                #Automapping property is not matched. Source is auto-mapping. Dest is not. Remove this full access, then re-add it.
                Log-Debug "[Trace]Need Change from false to true. User:$($tempUser). Auto-Mapping: True." -ConsoleInfo $false
                $noErrors=$true
                try
                {
                  Remove-MailboxPermission -Identity $info.DestinationMailbox -AccessRights FullAccess -User $mappedUser -Confirm: $false -ErrorAction Stop
                  try
                  {
                     Add-MailboxPermission -Identity $info.DestinationMailbox -AccessRights FullAccess -User $mappedUser -AutoMapping $true -ErrorAction Stop
                  }
                  catch
                  {
                    Log-Error "Failed to add the permission while changing the property from false to true. Mailbox: $($info.DestinationMailbox). User: $($mappedUser). Reason:$($_.Exception.Message)"
                    $mobj | Add-Member -MemberType NoteProperty -Name "Status" -Value 'Failed'
                    $mobj | Add-Member -MemberType NoteProperty -Name "Comment" -Value "Failed to re-add the permission. Reason:$($_.Exception.Message)"
                    $noErrors=$false
                  }
                }
                catch
                {
                  Log-Error "Failed to remove the permission while changing the property from false to true. Mailbox: $($info.DestinationMailbox). User: $($mappedUser). Reason:$($_.Exception.Message)"
                  $mobj | Add-Member -MemberType NoteProperty -Name "Status" -Value 'Failed'
                  $mobj | Add-Member -MemberType NoteProperty -Name "Comment" -Value "Failed to remove the permission. Reason:$($_.Exception.Message)"
                  $noErrors=$false
                }
                if($noErrors)
                {
                  $mobj | Add-Member -MemberType NoteProperty -Name "Status" -Value 'Successful'
                  $mobj | Add-Member -MemberType NoteProperty -Name "Comment" -Value 'Changed the property from false to true.'
                }
                else
                {
                  $hasNoError=$false
                }
             }
             else
             {
                #This user does not have full access on destination mailbox. Add it.
                Log-Debug "[Trace]Need add a new permission. User:$($tempUser). Auto-Mapping: True." -ConsoleInfo $false
                $noErrors=$true
                try
                {
                  Add-MailboxPermission -Identity $info.DestinationMailbox -AccessRights FullAccess -User $mappedUser -AutoMapping $true -ErrorAction Stop
                }
                catch
                {
                  Log-Error "Failed to add the permission. Mailbox: $($info.DestinationMailbox). User: $($mappedUser). Auto-Mapping: True. Reason:$($_.Exception.Message)"
                  $mobj | Add-Member -MemberType NoteProperty -Name "Status" -Value 'Failed'
                  $mobj | Add-Member -MemberType NoteProperty -Name "Comment" -Value "Failed to add the permission. Reason:$($_.Exception.Message)"
                  $noErrors=$false
                }
                if($noErrors)
                {
                  $mobj | Add-Member -MemberType NoteProperty -Name "Status" -Value 'Successful'
                  $mobj | Add-Member -MemberType NoteProperty -Name "Comment" -Value 'The permission is newly added in the destination.'
                }
                else
                {
                  $hasNoError=$false
                }
             }
           }
           else
           {
            $mobj | Add-Member -MemberType NoteProperty -Name "Status" -Value 'Failed'
            $mobj | Add-Member -MemberType NoteProperty -Name "Comment" -Value 'No destination user is configured for the source user in the UserOrGroupMappings.csv file.'
            Log-Error "Failed to add the permission. Auto-Mapping: True. Reason: No destination user is configured for the source user in the UserOrGroupMappings.csv file. Source user:$($tempUser)"
           }
           $result += $mobj
         }
          #Process AutoMapping is false in source
         foreach($tempUser in $Source_Not_AutoMapping)
         {
            $tempUser=$tempUser.ToLower().Trim()
            Log-Debug "[Trace]Begin to process user:$($tempUser). Auto-Mapping: True." -ConsoleInfo $false
            $mappedUser= GetUserFromMapping($tempUser.ToLower().Trim());
            $mobj = New-Object -TypeName PSCustomObject
            $mobj | Add-Member -MemberType NoteProperty -Name "SourceMailbox" -Value $info.SourceMailbox.ToLower()
            $mobj | Add-Member -MemberType NoteProperty -Name "DestinationMailbox" -Value $info.DestinationMailbox.ToLower()  
            $mobj | Add-Member -MemberType NoteProperty -Name "SourceUser" -Value  $tempUser
            $mobj | Add-Member -MemberType NoteProperty -Name "DestinationUser" -Value  $mappedUser
            $mobj | Add-Member -MemberType NoteProperty -Name "AutoMapping" -Value 'False'
           if($mappedUser -ne '')
           {
             if($users_Not_AutoMapping.Contains($mappedUser))
             {
                #This user has correct automapping property on destination, skip it.
                Log-Debug "[Trace]Skip due to same property. User:$($tempUser). Auto-Mapping: False." -ConsoleInfo $false
                $mobj | Add-Member -MemberType NoteProperty -Name "Status" -Value 'Skipped'
                $mobj | Add-Member -MemberType NoteProperty -Name "Comment" -Value 'The auto-mapping property is consistent.'
             }
             elseif($users_AutoMapping.Contains($mappedUser))
             {
                #Automapping property is not matched. Source is not auto-mapping. Dest is. Remove this full access, then re-add it.
                Log-Debug "[Trace]Need Change from true to false. User:$($tempUser). Auto-Mapping: True." -ConsoleInfo $false
                $noErrors=$true
                try
                {
                  Remove-MailboxPermission -Identity $info.DestinationMailbox -AccessRights FullAccess -User $mappedUser -Confirm: $false -ErrorAction Stop
                  try
                  {
                     Add-MailboxPermission -Identity $info.DestinationMailbox -AccessRights FullAccess -User $mappedUser -AutoMapping $false -ErrorAction Stop
                  }
                  catch
                  {
                    Log-Error "Failed to add the permission while changing the property from true to false. Mailbox: $($info.DestinationMailbox). User: $($mappedUser). Reason:$($_.Exception.Message)"
                    $mobj | Add-Member -MemberType NoteProperty -Name "Status" -Value 'Failed'
                    $mobj | Add-Member -MemberType NoteProperty -Name "Comment" -Value "Failed to re-add the permission. Reason:$($_.Exception.Message)"
                    $noErrors=$false
                   }
                  }
                catch
                {
                  Log-Error "Failed to add the permission while changing the property from true to false. Mailbox: $($info.DestinationMailbox). User: $($mappedUser). Reason:$($_.Exception.Message)"
                  $mobj | Add-Member -MemberType NoteProperty -Name "Status" -Value 'Failed'
                  $mobj | Add-Member -MemberType NoteProperty -Name "Comment" -Value "Failed to remove the permission. Reason:$($_.Exception.Message)"
                  $noErrors=$false
                }
                
                if($noErrors)
                {
                  $mobj | Add-Member -MemberType NoteProperty -Name "Status" -Value 'Successful'
                  $mobj | Add-Member -MemberType NoteProperty -Name "Comment" -Value 'Changed the property from true to false'
                }
                else
                {
                  $hasNoError=$false
                }
             }
             else
             {
                #This user does not have full access on destination mailbox. Add it.
                Log-Debug "[Trace]Need add a new permission. User:$($tempUser). Auto-Mapping: False." -ConsoleInfo $false
                $noErrors=$true
                try
                {
                  Add-MailboxPermission -Identity $info.DestinationMailbox -AccessRights FullAccess -User $mappedUser -AutoMapping $false -ErrorAction Stop
                }
                catch
                {
                  Log-Error "Failed to add the permission. Mailbox: $($info.DestinationMailbox). User: $($mappedUser). Auto-Mapping: False. Reason:$($_.Exception.Message)"
                  $mobj | Add-Member -MemberType NoteProperty -Name "Status" -Value 'Failed'
                  $mobj | Add-Member -MemberType NoteProperty -Name "Comment" -Value "Failed to add the permission. Reason:$($_.Exception.Message)"
                  $noErrors=$false
                }
                if($noErrors)
                {
                  $mobj | Add-Member -MemberType NoteProperty -Name "Status" -Value 'Successful'
                  $mobj | Add-Member -MemberType NoteProperty -Name "Comment" -Value 'The permission is newly added in the destination.'
                }
                else
                {
                  $hasNoError=$false
                }
             }
           }
           else
           {
            $mobj | Add-Member -MemberType NoteProperty -Name "Status" -Value 'Failed'
            $mobj | Add-Member -MemberType NoteProperty -Name "Comment" -Value 'No destination user is configured for the source user in the UserOrGroupMappings.csv file.'
            Log-Error "Failed to add the permission. Auto-Mapping: False. Reason: No destination user is configured for the source user in the UserOrGroupMappings.csv file. Source user:$($tempUser)"
           }
           $result += $mobj
         }
      }
      catch
      {
         Log-Error -Message "Failed to to process Mailbox: $($info.DestinationMailbox). Reason:$($_.Exception.Message)"
         $mobj = New-Object -TypeName PSCustomObject
         $mobj | Add-Member -MemberType NoteProperty -Name "SourceMailbox" -Value $info.SourceMailbox.ToLower()
         $mobj | Add-Member -MemberType NoteProperty -Name "DestinationMailbox" -Value $info.DestinationMailbox.ToLower()  
         $mobj | Add-Member -MemberType NoteProperty -Name "SourceUser" -Value ''
         $mobj | Add-Member -MemberType NoteProperty -Name "DestinationUser" -Value ''
         $mobj | Add-Member -MemberType NoteProperty -Name "AutoMapping" -Value ''
         $mobj | Add-Member -MemberType NoteProperty -Name "Status" -Value 'Failed'
         $mobj | Add-Member -MemberType NoteProperty -Name "Comment" -Value $_.Exception.Message
         $hasNoError=$false
         $result += $mobj
      }
    }
    $result | Export-Csv -Path $reportPath -NoTypeInformation -Encoding UTF8
    if($connectEx)
    {
     try
     {
       Disconnect-ExchangeOnline -Confirm: $false
       Log-Info "Successfully disconnected the Exchange Online."
     }
     catch
     {
       Log-Warning "Failed to disconnect exchange online. Reason:$($_.Exception)" -ConsoleInfo $false
     }
    }
    if($hasNoError)
    {
       Log-Info  "Execution finished. Navigate to $($reportPath) to view the execution report. You can also view the job logs in the Logs folder of the same directory. Logs:$($logName)."
    }
    else
    {
       Log-Warning "Execution finished with exceptions. Navigate to $($reportPath) to view the execution report. You can also view the job logs in the Logs folder of the same directory. Logs: $($logName)."
    }
}
catch
{
 if($connectEx)
    {
     try
     {
       Disconnect-ExchangeOnline -Confirm: $false
       Log-Info "Successfully disconnected the Exchange Online."
     }
     catch
     {
       Log-Warning "Failed to disconnect exchange online. Reason:$($_.Exception)" -ConsoleInfo $false
     }
    }
  Log-Error -Message "Failed to migrate the permissions of shared mailboxes. Reason:$($_.Exception.Message)"
  Log-Error -Message "Failed to migrate the permissions of shared mailboxes. Reason:$($_.Exception)" -ConsoleInfo $false
}
   



# SIG # Begin signature block
# MIIoZAYJKoZIhvcNAQcCoIIoVTCCKFECAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBjAy8RnOgQtYdm
# BbZSsnfD8sWw/wzCUSuSP04FTxPRXqCCDZowggawMIIEmKADAgECAhAIrUCyYNKc
# TJ9ezam9k67ZMA0GCSqGSIb3DQEBDAUAMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQK
# EwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNV
# BAMTGERpZ2lDZXJ0IFRydXN0ZWQgUm9vdCBHNDAeFw0yMTA0MjkwMDAwMDBaFw0z
# NjA0MjgyMzU5NTlaMGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwg
# SW5jLjFBMD8GA1UEAxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBDb2RlIFNpZ25pbmcg
# UlNBNDA5NiBTSEEzODQgMjAyMSBDQTEwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAw
# ggIKAoICAQDVtC9C0CiteLdd1TlZG7GIQvUzjOs9gZdwxbvEhSYwn6SOaNhc9es0
# JAfhS0/TeEP0F9ce2vnS1WcaUk8OoVf8iJnBkcyBAz5NcCRks43iCH00fUyAVxJr
# Q5qZ8sU7H/Lvy0daE6ZMswEgJfMQ04uy+wjwiuCdCcBlp/qYgEk1hz1RGeiQIXhF
# LqGfLOEYwhrMxe6TSXBCMo/7xuoc82VokaJNTIIRSFJo3hC9FFdd6BgTZcV/sk+F
# LEikVoQ11vkunKoAFdE3/hoGlMJ8yOobMubKwvSnowMOdKWvObarYBLj6Na59zHh
# 3K3kGKDYwSNHR7OhD26jq22YBoMbt2pnLdK9RBqSEIGPsDsJ18ebMlrC/2pgVItJ
# wZPt4bRc4G/rJvmM1bL5OBDm6s6R9b7T+2+TYTRcvJNFKIM2KmYoX7BzzosmJQay
# g9Rc9hUZTO1i4F4z8ujo7AqnsAMrkbI2eb73rQgedaZlzLvjSFDzd5Ea/ttQokbI
# YViY9XwCFjyDKK05huzUtw1T0PhH5nUwjewwk3YUpltLXXRhTT8SkXbev1jLchAp
# QfDVxW0mdmgRQRNYmtwmKwH0iU1Z23jPgUo+QEdfyYFQc4UQIyFZYIpkVMHMIRro
# OBl8ZhzNeDhFMJlP/2NPTLuqDQhTQXxYPUez+rbsjDIJAsxsPAxWEQIDAQABo4IB
# WTCCAVUwEgYDVR0TAQH/BAgwBgEB/wIBADAdBgNVHQ4EFgQUaDfg67Y7+F8Rhvv+
# YXsIiGX0TkIwHwYDVR0jBBgwFoAU7NfjgtJxXWRM3y5nP+e6mK4cD08wDgYDVR0P
# AQH/BAQDAgGGMBMGA1UdJQQMMAoGCCsGAQUFBwMDMHcGCCsGAQUFBwEBBGswaTAk
# BggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNlcnQuY29tMEEGCCsGAQUFBzAC
# hjVodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkUm9v
# dEc0LmNydDBDBgNVHR8EPDA6MDigNqA0hjJodHRwOi8vY3JsMy5kaWdpY2VydC5j
# b20vRGlnaUNlcnRUcnVzdGVkUm9vdEc0LmNybDAcBgNVHSAEFTATMAcGBWeBDAED
# MAgGBmeBDAEEATANBgkqhkiG9w0BAQwFAAOCAgEAOiNEPY0Idu6PvDqZ01bgAhql
# +Eg08yy25nRm95RysQDKr2wwJxMSnpBEn0v9nqN8JtU3vDpdSG2V1T9J9Ce7FoFF
# UP2cvbaF4HZ+N3HLIvdaqpDP9ZNq4+sg0dVQeYiaiorBtr2hSBh+3NiAGhEZGM1h
# mYFW9snjdufE5BtfQ/g+lP92OT2e1JnPSt0o618moZVYSNUa/tcnP/2Q0XaG3Ryw
# YFzzDaju4ImhvTnhOE7abrs2nfvlIVNaw8rpavGiPttDuDPITzgUkpn13c5Ubdld
# AhQfQDN8A+KVssIhdXNSy0bYxDQcoqVLjc1vdjcshT8azibpGL6QB7BDf5WIIIJw
# 8MzK7/0pNVwfiThV9zeKiwmhywvpMRr/LhlcOXHhvpynCgbWJme3kuZOX956rEnP
# LqR0kq3bPKSchh/jwVYbKyP/j7XqiHtwa+aguv06P0WmxOgWkVKLQcBIhEuWTatE
# QOON8BUozu3xGFYHKi8QxAwIZDwzj64ojDzLj4gLDb879M4ee47vtevLt/B3E+bn
# KD+sEq6lLyJsQfmCXBVmzGwOysWGw/YmMwwHS6DTBwJqakAwSEs0qFEgu60bhQji
# WQ1tygVQK+pKHJ6l/aCnHwZ05/LWUpD9r4VIIflXO7ScA+2GRfS0YW6/aOImYIbq
# yK+p/pQd52MbOoZWeE4wggbiMIIEyqADAgECAhAPc9sqd/BkUUsWn0FQMB0UMA0G
# CSqGSIb3DQEBCwUAMGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwg
# SW5jLjFBMD8GA1UEAxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBDb2RlIFNpZ25pbmcg
# UlNBNDA5NiBTSEEzODQgMjAyMSBDQTEwHhcNMjMxMTAzMDAwMDAwWhcNMjYxMTE0
# MjM1OTU5WjBqMQswCQYDVQQGEwJVUzETMBEGA1UECBMKTmV3IEplcnNleTEUMBIG
# A1UEBxMLSmVyc2V5IENpdHkxFzAVBgNVBAoTDkF2ZVBvaW50LCBJbmMuMRcwFQYD
# VQQDEw5BdmVQb2ludCwgSW5jLjCCAaIwDQYJKoZIhvcNAQEBBQADggGPADCCAYoC
# ggGBAOEW7Ii2pvR9/732eojqygVHkWY2HMdaefS7g4Z4EOt6ABrXYcTFvIMax1DN
# 7ZCbfarSe6B0jsXnrNbhTZKJiphzbLAIs4NOi4EMxdWzDbc8oZqByMX77NxSiaR3
# PhqFGI99Utr9NUIBsruS6AccQ6CkP2nNejixv6BrsGJbUDrgz6A66x7V4WhYa6df
# qmMU8EucSyjcZB2A4h21H+jURe95N1SZThOw6vfFKn5JPnKvGTCuH0u19xi8d90j
# ZItOntrR92wzFG2jSd4Z3DeKyvIDWxGGqaDqloA7thXNGN/URNqTZfeXdsF6uUU2
# IojpWh8gYBTnu9i8cM9PVDOB420h5JaV+1XLO8m10LtnYBSWZWgUHpcTq7Suwbah
# 0/yiur0ltzR13dQ0wk2Xe1i/G8PlKw4IlyqESqizT3YxUGlqwcojIAYwaGBtATTf
# kCKq32rornXSmCqfrQICoA8dR7pry8hl/JloSD/+riT62F8r8mQTlLUw5xNiqBqE
# kIQvuQIDAQABo4ICAzCCAf8wHwYDVR0jBBgwFoAUaDfg67Y7+F8Rhvv+YXsIiGX0
# TkIwHQYDVR0OBBYEFJxiV1oIFotUW4UTNkwFNyJScORPMD4GA1UdIAQ3MDUwMwYG
# Z4EMAQQBMCkwJwYIKwYBBQUHAgEWG2h0dHA6Ly93d3cuZGlnaWNlcnQuY29tL0NQ
# UzAOBgNVHQ8BAf8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwgbUGA1UdHwSB
# rTCBqjBToFGgT4ZNaHR0cDovL2NybDMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0VHJ1
# c3RlZEc0Q29kZVNpZ25pbmdSU0E0MDk2U0hBMzg0MjAyMUNBMS5jcmwwU6BRoE+G
# TWh0dHA6Ly9jcmw0LmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydFRydXN0ZWRHNENvZGVT
# aWduaW5nUlNBNDA5NlNIQTM4NDIwMjFDQTEuY3JsMIGUBggrBgEFBQcBAQSBhzCB
# hDAkBggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNlcnQuY29tMFwGCCsGAQUF
# BzAChlBodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVk
# RzRDb2RlU2lnbmluZ1JTQTQwOTZTSEEzODQyMDIxQ0ExLmNydDAJBgNVHRMEAjAA
# MA0GCSqGSIb3DQEBCwUAA4ICAQDE9SZRwvtvpHrw4OjJ1AKL0aabKlOUkxidOjEC
# wrWr4yFKJdHWHpouUFTye7M8gQS4FQDQqD4ys7a1joCQVd+WEiQIyy0TzJXxT7US
# tkhg8lD41cT7i857dgnSrX7Prp0Es/xFBhEKR0fMs3Sj20+qcnJNTB4TA9CPnUd4
# UL1Ve/bqsr5lVZgoPp6wbs0lXjsTEfzrio++T4ssc42eTxfv6YZgTmdrPEQNqLUa
# hQuQ0x5j8lVBBtt5PrC7TikkVB/GBZ+01EJrUQvcX3arZky1tviINBQ3EXRhyGkx
# zSz6Vk9NxwJVkdavIUkdDuUuqNVqp2a3Zsv2L3mwlr0UnKMgpBiPnxgC9u6e5tjR
# +plDe3fmD20XQTt/p61FueC7w92HC6YizDrynRX58h6KuRv2j/u2yZU3nipaiGlz
# 8jURf2ySxZXI2QG228Nfsg4y1Z61tPfYb4kcqTfVcaxh7azpP6BU33dkIyC7dmv4
# q3PueRcSyweKjqlQqeswnTeBS3+met1BbjkMdJJzqbIu5WONTBIHHH1RGsQYPn8i
# ms3pE0GhGl9c1r1BpufehQwSjCZRc/vHrHUOQyNimVKoOtls5UAxU5FXO3PKaHPO
# M6dFS1b+EF6drXV0M9/KdJVyyP4EK6CJQVt7RrQBRSSdQCKCYJ63VUF5amRuzY0s
# EqLoRTGCGiAwghocAgEBMH0waTELMAkGA1UEBhMCVVMxFzAVBgNVBAoTDkRpZ2lD
# ZXJ0LCBJbmMuMUEwPwYDVQQDEzhEaWdpQ2VydCBUcnVzdGVkIEc0IENvZGUgU2ln
# bmluZyBSU0E0MDk2IFNIQTM4NCAyMDIxIENBMQIQD3PbKnfwZFFLFp9BUDAdFDAN
# BglghkgBZQMEAgEFAKB8MBAGCisGAQQBgjcCAQwxAjAAMBkGCSqGSIb3DQEJAzEM
# BgorBgEEAYI3AgEEMBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMC8GCSqG
# SIb3DQEJBDEiBCCKzFNUMfC7Hf5yNU+7Clk1Xv5W3f+n0KrwcDVNSZ/BYDANBgkq
# hkiG9w0BAQEFAASCAYCE1WKFyg7hg1//qAG8ftqC+l844pRrG0CGuwmv+ABIW2kL
# ljQJZnyTLKkxSX8J8JTkDLfQcdSRcqoO6sUsMRJrw3putRw6DA2kp46ol5y/alXZ
# UiUfxjeJWDw3+51J3KeefjCa/aZ3ZUABb+2n7JvHLFrxaFaMV94CZfbTZyKHsUkB
# BCucZC4FoRGgeT++3/3DAUPBI7ktz72Ke1dwTl2JGEmI9nZJqiwWpkxRaihY57qm
# q/qibHue4vQHiyJUkTH/UxMnr9Zu8OCtaKfqH/PhS8ePIz1S13jcrp4vtb7+AsUZ
# n2IMkzhhVMCI5rDCUE7TXbPwQvGW7MtHebdqPzzDAd2TZOmSe3nLtdCqoMcuEKfY
# BxbdeeTWHHVTmNr+PcaM7kK2gb0YOxVe8uP72TOTriiMYJfu5MiRTsOswUEuNv+s
# KzPGOVXdF+Dx0tqq+B2Mi9yJuYmCpLVpnsnnVCGTwy3xZNG+akHxxQsDE6zrmAX0
# GFW+oJpnQmW4Qy6HDpuhghd2MIIXcgYKKwYBBAGCNwMDATGCF2IwghdeBgkqhkiG
# 9w0BBwKgghdPMIIXSwIBAzEPMA0GCWCGSAFlAwQCAQUAMHcGCyqGSIb3DQEJEAEE
# oGgEZjBkAgEBBglghkgBhv1sBwEwMTANBglghkgBZQMEAgEFAAQgsFo3YrH5KCqE
# Ho/folPzLQfOE7d5wKnhX4VMM14J3qQCEHu9Fil2vs19tdE/QqxJFmEYDzIwMjYw
# MTA1MDUzNzExWqCCEzowggbtMIIE1aADAgECAhAKgO8YS43xBYLRxHanlXRoMA0G
# CSqGSIb3DQEBCwUAMGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwg
# SW5jLjFBMD8GA1UEAxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBUaW1lU3RhbXBpbmcg
# UlNBNDA5NiBTSEEyNTYgMjAyNSBDQTEwHhcNMjUwNjA0MDAwMDAwWhcNMzYwOTAz
# MjM1OTU5WjBjMQswCQYDVQQGEwJVUzEXMBUGA1UEChMORGlnaUNlcnQsIEluYy4x
# OzA5BgNVBAMTMkRpZ2lDZXJ0IFNIQTI1NiBSU0E0MDk2IFRpbWVzdGFtcCBSZXNw
# b25kZXIgMjAyNSAxMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEA0Eas
# LRLGntDqrmBWsytXum9R/4ZwCgHfyjfMGUIwYzKomd8U1nH7C8Dr0cVMF3BsfAFI
# 54um8+dnxk36+jx0Tb+k+87H9WPxNyFPJIDZHhAqlUPt281mHrBbZHqRK71Em3/h
# CGC5KyyneqiZ7syvFXJ9A72wzHpkBaMUNg7MOLxI6E9RaUueHTQKWXymOtRwJXcr
# cTTPPT2V1D/+cFllESviH8YjoPFvZSjKs3SKO1QNUdFd2adw44wDcKgH+JRJE5Qg
# 0NP3yiSyi5MxgU6cehGHr7zou1znOM8odbkqoK+lJ25LCHBSai25CFyD23DZgPfD
# rJJJK77epTwMP6eKA0kWa3osAe8fcpK40uhktzUd/Yk0xUvhDU6lvJukx7jphx40
# DQt82yepyekl4i0r8OEps/FNO4ahfvAk12hE5FVs9HVVWcO5J4dVmVzix4A77p3a
# wLbr89A90/nWGjXMGn7FQhmSlIUDy9Z2hSgctaepZTd0ILIUbWuhKuAeNIeWrzHK
# YueMJtItnj2Q+aTyLLKLM0MheP/9w6CtjuuVHJOVoIJ/DtpJRE7Ce7vMRHoRon4C
# WIvuiNN1Lk9Y+xZ66lazs2kKFSTnnkrT3pXWETTJkhd76CIDBbTRofOsNyEhzZtC
# GmnQigpFHti58CSmvEyJcAlDVcKacJ+A9/z7eacCAwEAAaOCAZUwggGRMAwGA1Ud
# EwEB/wQCMAAwHQYDVR0OBBYEFOQ7/PIx7f391/ORcWMZUEPPYYzoMB8GA1UdIwQY
# MBaAFO9vU0rp5AZ8esrikFb2L9RJ7MtOMA4GA1UdDwEB/wQEAwIHgDAWBgNVHSUB
# Af8EDDAKBggrBgEFBQcDCDCBlQYIKwYBBQUHAQEEgYgwgYUwJAYIKwYBBQUHMAGG
# GGh0dHA6Ly9vY3NwLmRpZ2ljZXJ0LmNvbTBdBggrBgEFBQcwAoZRaHR0cDovL2Nh
# Y2VydHMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0VHJ1c3RlZEc0VGltZVN0YW1waW5n
# UlNBNDA5NlNIQTI1NjIwMjVDQTEuY3J0MF8GA1UdHwRYMFYwVKBSoFCGTmh0dHA6
# Ly9jcmwzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydFRydXN0ZWRHNFRpbWVTdGFtcGlu
# Z1JTQTQwOTZTSEEyNTYyMDI1Q0ExLmNybDAgBgNVHSAEGTAXMAgGBmeBDAEEAjAL
# BglghkgBhv1sBwEwDQYJKoZIhvcNAQELBQADggIBAGUqrfEcJwS5rmBB7NEIRJ5j
# QHIh+OT2Ik/bNYulCrVvhREafBYF0RkP2AGr181o2YWPoSHz9iZEN/FPsLSTwVQW
# o2H62yGBvg7ouCODwrx6ULj6hYKqdT8wv2UV+Kbz/3ImZlJ7YXwBD9R0oU62Ptgx
# Oao872bOySCILdBghQ/ZLcdC8cbUUO75ZSpbh1oipOhcUT8lD8QAGB9lctZTTOJM
# 3pHfKBAEcxQFoHlt2s9sXoxFizTeHihsQyfFg5fxUFEp7W42fNBVN4ueLaceRf9C
# q9ec1v5iQMWTFQa0xNqItH3CPFTG7aEQJmmrJTV3Qhtfparz+BW60OiMEgV5GWoB
# y4RVPRwqxv7Mk0Sy4QHs7v9y69NBqycz0BZwhB9WOfOu/CIJnzkQTwtSSpGGhLdj
# nQ4eBpjtP+XB3pQCtv4E5UCSDag6+iX8MmB10nfldPF9SVD7weCC3yXZi/uuhqdw
# kgVxuiMFzGVFwYbQsiGnoa9F5AaAyBjFBtXVLcKtapnMG3VH3EmAp/jsJ3FVF3+d
# 1SVDTmjFjLbNFZUWMXuZyvgLfgyPehwJVxwC+UpX2MSey2ueIu9THFVkT+um1vsh
# ETaWyQo8gmBto/m3acaP9QsuLj3FNwFlTxq25+T4QwX9xa6ILs84ZPvmpovq90K8
# eWyG2N01c4IhSOxqt81nMIIGtDCCBJygAwIBAgIQDcesVwX/IZkuQEMiDDpJhjAN
# BgkqhkiG9w0BAQsFADBiMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNlcnQg
# SW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMSEwHwYDVQQDExhEaWdpQ2Vy
# dCBUcnVzdGVkIFJvb3QgRzQwHhcNMjUwNTA3MDAwMDAwWhcNMzgwMTE0MjM1OTU5
# WjBpMQswCQYDVQQGEwJVUzEXMBUGA1UEChMORGlnaUNlcnQsIEluYy4xQTA/BgNV
# BAMTOERpZ2lDZXJ0IFRydXN0ZWQgRzQgVGltZVN0YW1waW5nIFJTQTQwOTYgU0hB
# MjU2IDIwMjUgQ0ExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAtHgx
# 0wqYQXK+PEbAHKx126NGaHS0URedTa2NDZS1mZaDLFTtQ2oRjzUXMmxCqvkbsDpz
# 4aH+qbxeLho8I6jY3xL1IusLopuW2qftJYJaDNs1+JH7Z+QdSKWM06qchUP+AbdJ
# gMQB3h2DZ0Mal5kYp77jYMVQXSZH++0trj6Ao+xh/AS7sQRuQL37QXbDhAktVJMQ
# bzIBHYJBYgzWIjk8eDrYhXDEpKk7RdoX0M980EpLtlrNyHw0Xm+nt5pnYJU3Gmq6
# bNMI1I7Gb5IBZK4ivbVCiZv7PNBYqHEpNVWC2ZQ8BbfnFRQVESYOszFI2Wv82wnJ
# RfN20VRS3hpLgIR4hjzL0hpoYGk81coWJ+KdPvMvaB0WkE/2qHxJ0ucS638ZxqU1
# 4lDnki7CcoKCz6eum5A19WZQHkqUJfdkDjHkccpL6uoG8pbF0LJAQQZxst7VvwDD
# jAmSFTUms+wV/FbWBqi7fTJnjq3hj0XbQcd8hjj/q8d6ylgxCZSKi17yVp2NL+cn
# T6Toy+rN+nM8M7LnLqCrO2JP3oW//1sfuZDKiDEb1AQ8es9Xr/u6bDTnYCTKIsDq
# 1BtmXUqEG1NqzJKS4kOmxkYp2WyODi7vQTCBZtVFJfVZ3j7OgWmnhFr4yUozZtqg
# PrHRVHhGNKlYzyjlroPxul+bgIspzOwbtmsgY1MCAwEAAaOCAV0wggFZMBIGA1Ud
# EwEB/wQIMAYBAf8CAQAwHQYDVR0OBBYEFO9vU0rp5AZ8esrikFb2L9RJ7MtOMB8G
# A1UdIwQYMBaAFOzX44LScV1kTN8uZz/nupiuHA9PMA4GA1UdDwEB/wQEAwIBhjAT
# BgNVHSUEDDAKBggrBgEFBQcDCDB3BggrBgEFBQcBAQRrMGkwJAYIKwYBBQUHMAGG
# GGh0dHA6Ly9vY3NwLmRpZ2ljZXJ0LmNvbTBBBggrBgEFBQcwAoY1aHR0cDovL2Nh
# Y2VydHMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0VHJ1c3RlZFJvb3RHNC5jcnQwQwYD
# VR0fBDwwOjA4oDagNIYyaHR0cDovL2NybDMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0
# VHJ1c3RlZFJvb3RHNC5jcmwwIAYDVR0gBBkwFzAIBgZngQwBBAIwCwYJYIZIAYb9
# bAcBMA0GCSqGSIb3DQEBCwUAA4ICAQAXzvsWgBz+Bz0RdnEwvb4LyLU0pn/N0IfF
# iBowf0/Dm1wGc/Do7oVMY2mhXZXjDNJQa8j00DNqhCT3t+s8G0iP5kvN2n7Jd2E4
# /iEIUBO41P5F448rSYJ59Ib61eoalhnd6ywFLerycvZTAz40y8S4F3/a+Z1jEMK/
# DMm/axFSgoR8n6c3nuZB9BfBwAQYK9FHaoq2e26MHvVY9gCDA/JYsq7pGdogP8HR
# trYfctSLANEBfHU16r3J05qX3kId+ZOczgj5kjatVB+NdADVZKON/gnZruMvNYY2
# o1f4MXRJDMdTSlOLh0HCn2cQLwQCqjFbqrXuvTPSegOOzr4EWj7PtspIHBldNE2K
# 9i697cvaiIo2p61Ed2p8xMJb82Yosn0z4y25xUbI7GIN/TpVfHIqQ6Ku/qjTY6hc
# 3hsXMrS+U0yy+GWqAXam4ToWd2UQ1KYT70kZjE4YtL8Pbzg0c1ugMZyZZd/BdHLi
# Ru7hAWE6bTEm4XYRkA6Tl4KSFLFk43esaUeqGkH/wyW4N7OigizwJWeukcyIPbAv
# jSabnf7+Pu0VrFgoiovRDiyx3zEdmcif/sYQsfch28bZeUz2rtY/9TCA6TD8dC3J
# E3rYkrhLULy7Dc90G6e8BlqmyIjlgp2+VqsS9/wQD7yFylIz0scmbKvFoW2jNrbM
# 1pD2T7m3XDCCBY0wggR1oAMCAQICEA6bGI750C3n79tQ4ghAGFowDQYJKoZIhvcN
# AQEMBQAwZTELMAkGA1UEBhMCVVMxFTATBgNVBAoTDERpZ2lDZXJ0IEluYzEZMBcG
# A1UECxMQd3d3LmRpZ2ljZXJ0LmNvbTEkMCIGA1UEAxMbRGlnaUNlcnQgQXNzdXJl
# ZCBJRCBSb290IENBMB4XDTIyMDgwMTAwMDAwMFoXDTMxMTEwOTIzNTk1OVowYjEL
# MAkGA1UEBhMCVVMxFTATBgNVBAoTDERpZ2lDZXJ0IEluYzEZMBcGA1UECxMQd3d3
# LmRpZ2ljZXJ0LmNvbTEhMB8GA1UEAxMYRGlnaUNlcnQgVHJ1c3RlZCBSb290IEc0
# MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAv+aQc2jeu+RdSjwwIjBp
# M+zCpyUuySE98orYWcLhKac9WKt2ms2uexuEDcQwH/MbpDgW61bGl20dq7J58soR
# 0uRf1gU8Ug9SH8aeFaV+vp+pVxZZVXKvaJNwwrK6dZlqczKU0RBEEC7fgvMHhOZ0
# O21x4i0MG+4g1ckgHWMpLc7sXk7Ik/ghYZs06wXGXuxbGrzryc/NrDRAX7F6Zu53
# yEioZldXn1RYjgwrt0+nMNlW7sp7XeOtyU9e5TXnMcvak17cjo+A2raRmECQecN4
# x7axxLVqGDgDEI3Y1DekLgV9iPWCPhCRcKtVgkEy19sEcypukQF8IUzUvK4bA3Vd
# eGbZOjFEmjNAvwjXWkmkwuapoGfdpCe8oU85tRFYF/ckXEaPZPfBaYh2mHY9WV1C
# doeJl2l6SPDgohIbZpp0yt5LHucOY67m1O+SkjqePdwA5EUlibaaRBkrfsCUtNJh
# besz2cXfSwQAzH0clcOP9yGyshG3u3/y1YxwLEFgqrFjGESVGnZifvaAsPvoZKYz
# 0YkH4b235kOkGLimdwHhD5QMIR2yVCkliWzlDlJRR3S+Jqy2QXXeeqxfjT/JvNNB
# ERJb5RBQ6zHFynIWIgnffEx1P2PsIV/EIFFrb7GrhotPwtZFX50g/KEexcCPorF+
# CiaZ9eRpL5gdLfXZqbId5RsCAwEAAaOCATowggE2MA8GA1UdEwEB/wQFMAMBAf8w
# HQYDVR0OBBYEFOzX44LScV1kTN8uZz/nupiuHA9PMB8GA1UdIwQYMBaAFEXroq/0
# ksuCMS1Ri6enIZ3zbcgPMA4GA1UdDwEB/wQEAwIBhjB5BggrBgEFBQcBAQRtMGsw
# JAYIKwYBBQUHMAGGGGh0dHA6Ly9vY3NwLmRpZ2ljZXJ0LmNvbTBDBggrBgEFBQcw
# AoY3aHR0cDovL2NhY2VydHMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0QXNzdXJlZElE
# Um9vdENBLmNydDBFBgNVHR8EPjA8MDqgOKA2hjRodHRwOi8vY3JsMy5kaWdpY2Vy
# dC5jb20vRGlnaUNlcnRBc3N1cmVkSURSb290Q0EuY3JsMBEGA1UdIAQKMAgwBgYE
# VR0gADANBgkqhkiG9w0BAQwFAAOCAQEAcKC/Q1xV5zhfoKN0Gz22Ftf3v1cHvZqs
# oYcs7IVeqRq7IviHGmlUIu2kiHdtvRoU9BNKei8ttzjv9P+Aufih9/Jy3iS8UgPI
# TtAq3votVs/59PesMHqai7Je1M/RQ0SbQyHrlnKhSLSZy51PpwYDE3cnRNTnf+hZ
# qPC/Lwum6fI0POz3A8eHqNJMQBk1RmppVLC4oVaO7KTVPeix3P0c2PR3WlxUjG/v
# oVA9/HYJaISfb8rbII01YBwCA8sgsKxYoA5AY8WYIsGyWfVVa88nq2x2zm8jLfR+
# cWojayL/ErhULSd+2DrZ8LaHlv1b0VysGMNNn3O3AamfV6peKOK5lDGCA3wwggN4
# AgEBMH0waTELMAkGA1UEBhMCVVMxFzAVBgNVBAoTDkRpZ2lDZXJ0LCBJbmMuMUEw
# PwYDVQQDEzhEaWdpQ2VydCBUcnVzdGVkIEc0IFRpbWVTdGFtcGluZyBSU0E0MDk2
# IFNIQTI1NiAyMDI1IENBMQIQCoDvGEuN8QWC0cR2p5V0aDANBglghkgBZQMEAgEF
# AKCB0TAaBgkqhkiG9w0BCQMxDQYLKoZIhvcNAQkQAQQwHAYJKoZIhvcNAQkFMQ8X
# DTI2MDEwNTA1MzcxMVowKwYLKoZIhvcNAQkQAgwxHDAaMBgwFgQU3WIwrIYKLTBr
# 2jixaHlSMAf7QX4wLwYJKoZIhvcNAQkEMSIEIOst+cwUI71Yl8MJIl7vHadkP6ej
# 6w1hr/tPHaR6zIVUMDcGCyqGSIb3DQEJEAIvMSgwJjAkMCIEIEqgP6Is11yExVyT
# j4KOZ2ucrsqzP+NtJpqjNPFGEQozMA0GCSqGSIb3DQEBAQUABIICAMUH6RaGHCbN
# ieR+2pNBJjY/c5gx/6iCBOBUcXNk8GGqy+ve32uLQX1FKE4cT7U2iLfHD6psJnJv
# //aP34zuEPvZaTY+5rvoRz/RuNfF7P1W9djh31s+qvjWi54Ha5HSy2XOMyEwh0oJ
# vemf9iL/hjI35OQt1t18poEWfu/xkkjmXJtNDil/GJQijU2EfFJIUYPL5jVx9mwg
# giMTDqZ+UIaQjUtTh74NsJLSd2e+P2sEc5VFb5LZEtshgP6t/B6gt0jPD5qRqDWu
# kI6BDDlKY5fxSdJ8Kxe4Ngxf5NvSpBG05M7aYCi4enw2iPNCUuYYpeiqeBKZxBpw
# Y6MvjlYBvNGGTo7Oa6OsfwlP7Mb21wNccCMz8HZ3wSdYRrN8s/dB7B7FrXHzA4Tj
# +ZrLfYnTokC0ipLnNKNpCYYBkOeoVmiZXeRhryKDXmDYy3p//WKrZG1hsfKQYNGn
# pWCYt1euDnfRYxTp/LjyvQKUpPAyk4KS46jSvAcOODsDVG9vzE8fFicYgm3RM+kj
# 2JTRas2Qmf/UyvgdVujoHSAzqHwosOIPUez3JiSPUXtBs/spfzvBGgkmAQ4qQfod
# vr9DJ/I4+DKrXrAuDNbpg1Xa+Fwi7TGYtB+MVxXLFVxd2dZfd89VyBApwSU9cEHt
# na/AM+Qnr0pv2/gs7++aEw6W4FhDpnNB
# SIG # End signature block
