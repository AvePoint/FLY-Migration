﻿<# /********************************************************************
 *
 *  PROPRIETARY and CONFIDENTIAL
 *
 *  This file is licensed from, and is a trade secret of:
 *
 *                   AvePoint, Inc.
 *                   525 Washington Blvd, Suite 1400
 *                   Jersey City, NJ 07310
 *                   United States of America
 *                   Telephone: +1-201-793-1111
 *                   WWW: www.avepoint.com
 *
 *  Refer to your License Agreement for restrictions on use,
 *  duplication, or disclosure.
 *
 *  RESTRICTED RIGHTS LEGEND
 *
 *  Use, duplication, or disclosure by the Government is
 *  subject to restrictions as set forth in subdivision
 *  (c)(1)(ii) of the Rights in Technical Data and Computer
 *  Software clause at DFARS 252.227-7013 (Oct. 1988) and
 *  FAR 52.227-19 (C) (June 1987).
 *
 *  Copyright © 2017-2024 AvePoint® Inc. All Rights Reserved. 
 *
 *  Unpublished - All rights reserved under the copyright laws of the United States.
 */ #>
$invocation = (Get-Variable MyInvocation).Value
$currentPath = (Get-Item $invocation.MyCommand.Path).Directory.FullName
."$currentPath\Common\LogFuncs.ps1"
$timestamp = Get-Date -UFormat %Y%m%d%H%M%S
$reportPath="$currentPath\GetDistributionGroups_$timestamp.csv";
$logName="BackupDistributionGroups_$timestamp.log";
$ret = @()
$csvPath= "$currentPath\GroupMappings.csv"
$csvContent =@()
$Script:ErrorActionPreference = "Stop"

try
{ 
 Log-Initialize -Path "$CurrentPath\Logs" -Name $logName
 $logFullPath = "$CurrentPath\Logs\$logName"
}
catch
{
  Write-Error "Failed to initialize the logs. Details: $($_.Exception.Message)"
  exit
}
if (test-path $csvPath)
{
  $csvContent= Import-Csv $csvPath
  $totalCount = $csvContent | Measure-Object | Select-Object -Expand Count
}
else
{
   Log-Error -Message  "Job failed. Failed to retrieve the `"GroupMappings.csv`" file in the $($csvPath) directory."
   exit
}
function FormatUser([string]$user)
{
    $result = $user
    if($user.Contains("/"))
    {
       $result = $user.Substring($user.LastIndexOf("/") + 1) 
    }
    if($user.Contains("\"))
    {
       $result = $user.Substring($user.LastIndexOf("\") + 1)
    }
    return $result
}
function GetNameFromAddress([string]$address)
{
    Log-Info "Start to retrieve the group name from the email address ""$($address)""."
    $group = Get-DistributionGroup -Identity $address | Select-Object Name -ErrorAction Stop
    $result = $group.Name
    Log-Info "Successfully retrieved the group name ""$($group.Name)"" from the email address ""$($address)""."
    return $result
}
function GetAddressFromName([string]$name)
{
    $result = $name
    try
    {
        $recipient = Get-Recipient -Identity $name | Select-Object -property PrimarySmtpAddress -ErrorAction Stop
        $result = $recipient.PrimarySmtpAddress
    }
    catch
    {
        $errorMessage = "Failed to retrieve the email address from the name ""$($name)"". Details: $($_.Exception.Message)"
        Log-Error -Message $errorMessage -ConsoleInfo $false
    }
    return $result
}
function GetOnPremMailboxSendAs([string]$name)
{
    [System.Collections.ArrayList]$sendAsPermission = @()
    $resultList = Get-AdPermission -Identity $name |Select-Object -property User,ExtendedRights,IsInherited -ErrorAction Stop
    foreach($prem in $resultList)
    {
        Log-Info "User:$($prem.User). ExtendedRights:$($prem.ExtendedRights). IsInherited:$($prem.IsInherited)." -ConsoleInfo $false

        if($prem.ExtendedRights -like "Send-As" -and $prem.IsInherited -eq $false -and $prem.User -like "*\*")
        {
            [string]$tempName = FormatUser($prem.User)
            [string]$tempAddress = GetAddressFromName($tempName)
            $sendAsPermission.Add($tempAddress) | out-null
        }
        else
        {
            Log-Info "Skip this permission: $($prem.User)." -ConsoleInfo $false
        }

    }
    return $sendAsPermission
}

function GetMailboxSendOnBehalf([string]$address)
{
    [System.Collections.ArrayList]$result = @()
    $sendOBPermission = Get-DistributionGroup -Identity $address | Select-Object GrantSendOnBehalfTo            
    foreach($permission in $sendOBPermission.GrantSendOnBehalfTo)
    {
        [string]$tempName = FormatUser($permission)
        [string]$tempAddress = GetAddressFromName($tempName)
        $result.Add($tempAddress) | out-null
    }
    return $result
}

#main
$failedGroupCount = 0
try      
{     
    if($csvContent)
    {
        do
        {
            [string]$environment =  Read-Host "Migrate Permissions?(Y or N)"
        }
        until ("y","n" -contains $environment)

        if($environment -eq "y")
        {
            $IsMigratePermissions = $true
        }
        else
        {
            $IsMigratePermissions = $false
        }
        foreach($mailbox in $csvContent)
        {
            if($mailbox.'Source Email Address' -and $mailbox.'Destination Email Address')
            {
                $hasSuccessfulObject = $false
                $sourceAddress = $mailbox.'Source Email Address'.Trim()
                $destTrimmedAddress = $mailbox.'Destination Email Address'.Trim()
                #GET Owners  
                try
                {
                    Log-Info "Start to retrieve the owners of the group ""$($sourceAddress)""." 
                    $dist = Get-DistributionGroup -Identity $sourceAddress | Select-Object ManagedBy
                    foreach($owner in $dist.ManagedBy)
                    {
                        [string]$tempName = FormatUser($owner)
                        [string]$tempAddress = GetAddressFromName($tempName)
                        $mobj = New-Object -TypeName PSCustomObject
                        $mobj | Add-Member -MemberType NoteProperty -Name "Source Email Address" -Value $sourceAddress
                        $mobj | Add-Member -MemberType NoteProperty -Name "Source Type" -Value $mailbox.'Source Type'
                        $mobj | Add-Member -MemberType NoteProperty -Name "Destination Email Address" -Value $destTrimmedAddress
                        $mobj | Add-Member -MemberType NoteProperty -Name "Destination Type" -Value $mailbox.'Destination Type'                                
                        $mobj | Add-Member -MemberType NoteProperty -Name "Type" -Value 'Owner'
                        $mobj | Add-Member -MemberType NoteProperty -Name "User" -Value $tempAddress
                        $mobj | Add-Member -MemberType NoteProperty -Name "Status" -Value 'Successful'
                        $mobj | Add-Member -MemberType NoteProperty -Name "Comment" -Value ''
                        $ret += $mobj
                    }
                    Log-Info "Successfully retrieved the owners of the group ""$($sourceAddress)""." 
                    $hasSuccessfulObject = $true
                }
                catch
                {
                    $errorMessage = "Failed to retrieve the group ""$($sourceAddress)"". Details: $($_.Exception.Message)"
                    Log-Error -Message $errorMessage
                    $mobj = New-Object -TypeName PSCustomObject
                    $mobj | Add-Member -MemberType NoteProperty -Name "Source Email Address" -Value $sourceAddress
                    $mobj | Add-Member -MemberType NoteProperty -Name "Source Type" -Value $mailbox.'Source Type'
                    $mobj | Add-Member -MemberType NoteProperty -Name "Destination Email Address" -Value $destTrimmedAddress 
                    $mobj | Add-Member -MemberType NoteProperty -Name "Destination Type" -Value $mailbox.'Destination Type'    
                    $mobj | Add-Member -MemberType NoteProperty -Name "Type" -Value 'All'
                    $mobj | Add-Member -MemberType NoteProperty -Name "User" -Value ''
                    $mobj | Add-Member -MemberType NoteProperty -Name "Status" -Value 'Failed'
                    $mobj | Add-Member -MemberType NoteProperty -Name "Comment" -Value $errorMessage
                    $ret += $mobj

                    $failedGroupCount ++
                    continue
                }

                #GET Members
                try
                {
                    Log-Info "Start to retrieve the members of the group ""$($sourceAddress)""." 
                    $memberList = Get-DistributionGroupMember -Identity $sourceAddress | Select-Object PrimarySmtpAddress                                
                    if($memberList)
                    {
                        foreach($member in $memberList)
                        {
                            $mobj = New-Object -TypeName PSCustomObject
                            $mobj | Add-Member -MemberType NoteProperty -Name "Source Email Address" -Value $sourceAddress
                            $mobj | Add-Member -MemberType NoteProperty -Name "Source Type" -Value $mailbox.'Source Type'
                            $mobj | Add-Member -MemberType NoteProperty -Name "Destination Email Address" -Value $destTrimmedAddress
                            $mobj | Add-Member -MemberType NoteProperty -Name "Destination Type" -Value $mailbox.'Destination Type' 
                            $mobj | Add-Member -MemberType NoteProperty -Name "Type" -Value 'Member'
                            $mobj | Add-Member -MemberType NoteProperty -Name "User" -Value $member.PrimarySmtpAddress
                            $mobj | Add-Member -MemberType NoteProperty -Name "Status" -Value 'Successful'
                            $mobj | Add-Member -MemberType NoteProperty -Name "Comment" -Value ''
                            $ret += $mobj
                        }       
                    }
                    else
                    {
                        Log-Info 'No members have been added to the source group.' -ConsoleInfo $false
                    }
                    Log-Info "Successfully retrieved the members of the group ""$($sourceAddress)""." 
                    $hasSuccessfulObject = $true
                }
                catch
                {
                    $errorMessage = "Failed to retrieve the members of the group ""$($sourceAddress)"". Details: $($_.Exception.Message)"
                    Log-Error -Message $errorMessage
                    $mobj = New-Object -TypeName PSCustomObject
                    $mobj | Add-Member -MemberType NoteProperty -Name "Source Email Address" -Value $sourceAddress
                    $mobj | Add-Member -MemberType NoteProperty -Name "Source Type" -Value $mailbox.'Source Type'
                    $mobj | Add-Member -MemberType NoteProperty -Name "Destination Email Address" -Value $destTrimmedAddress
                    $mobj | Add-Member -MemberType NoteProperty -Name "Destination Type" -Value $mailbox.'Destination Type'  
                    $mobj | Add-Member -MemberType NoteProperty -Name "Type" -Value 'Member'
                    $mobj | Add-Member -MemberType NoteProperty -Name "User" -Value ''
                    $mobj | Add-Member -MemberType NoteProperty -Name "Status" -Value 'Failed'
                    $mobj | Add-Member -MemberType NoteProperty -Name "Comment" -Value $errorMessage
                    $ret += $mobj
                }

                #GET Permissions
                if ($IsMigratePermissions -eq $true)
                {
                    $hasPermissions = $false
                    #GET Send As 
                    try
                    {
                        Log-Info "Start to retrieve the ""Send as"" permission of the group ""$($sourceAddress)""." 
                        $groupName = GetNameFromAddress($sourceAddress)                        
                        $sendAsList = GetOnPremMailboxSendAs($groupName)
                        if ($sendAsList)
                        {
                            $hasPermissions = $true
                            foreach($sendAs in $sendAsList)
                            {
                                $mobj = New-Object -TypeName PSCustomObject
                                $mobj | Add-Member -MemberType NoteProperty -Name "Source Email Address" -Value $sourceAddress
                                $mobj | Add-Member -MemberType NoteProperty -Name "Source Type" -Value $mailbox.'Source Type'
                                $mobj | Add-Member -MemberType NoteProperty -Name "Destination Email Address" -Value $destTrimmedAddress
                                $mobj | Add-Member -MemberType NoteProperty -Name "Destination Type" -Value $mailbox.'Destination Type' 
                                $mobj | Add-Member -MemberType NoteProperty -Name "Type" -Value 'Send As'
                                $mobj | Add-Member -MemberType NoteProperty -Name "User" -Value $sendAs
                                $mobj | Add-Member -MemberType NoteProperty -Name "Status" -Value 'Successful'
                                $mobj | Add-Member -MemberType NoteProperty -Name "Comment" -Value ''
                                $ret += $mobj
                            }
                        }
                        else
                        {
                            Log-Info 'No user or group is assigned "Send as" permission for the source group.' -ConsoleInfo $false                      
                        }
                        Log-Info "Successfully retrieved the ""Send as"" permission of the group ""$($sourceAddress)""." 
                        $hasSuccessfulObject = $true
                    }
                    catch
                    {
                        $errorMessage = "Failed to retrieve the ""Send as"" permission of the group ""$($sourceAddress)"". Details: $($_.Exception.Message)"
                        Log-Error -Message $errorMessage
                        $mobj = New-Object -TypeName PSCustomObject
                        $mobj | Add-Member -MemberType NoteProperty -Name "Source Email Address" -Value $sourceAddress
                        $mobj | Add-Member -MemberType NoteProperty -Name "Source Type" -Value $mailbox.'Source Type'
                        $mobj | Add-Member -MemberType NoteProperty -Name "Destination Email Address" -Value $destTrimmedAddress 
                        $mobj | Add-Member -MemberType NoteProperty -Name "Destination Type" -Value $mailbox.'Destination Type'  
                        $mobj | Add-Member -MemberType NoteProperty -Name "Type" -Value 'Send As'
                        $mobj | Add-Member -MemberType NoteProperty -Name "User" -Value ''
                        $mobj | Add-Member -MemberType NoteProperty -Name "Status" -Value 'Failed'
                        $mobj | Add-Member -MemberType NoteProperty -Name "Comment" -Value $errorMessage
                        $ret += $mobj
                    }


                    #GET Send On Behalf
                    try
                    {
                        Log-Info "Start to retrieve the ""Send on behalf"" permission of the group ""$($sourceAddress)""." 
                        $sendOBList = GetMailboxSendOnBehalf($sourceAddress)
                        if ($sendOBList)
                        {
                            $hasPermissions = $true
                            foreach($sendOB in $sendOBList)
                            {
                                $mobj = New-Object -TypeName PSCustomObject
                                $mobj | Add-Member -MemberType NoteProperty -Name "Source Email Address" -Value $sourceAddress
                                $mobj | Add-Member -MemberType NoteProperty -Name "Source Type" -Value $mailbox.'Source Type'
                                $mobj | Add-Member -MemberType NoteProperty -Name "Destination Email Address" -Value $destTrimmedAddress
                                $mobj | Add-Member -MemberType NoteProperty -Name "Destination Type" -Value $mailbox.'Destination Type' 
                                $mobj | Add-Member -MemberType NoteProperty -Name "Type" -Value 'Send On Behalf'
                                $mobj | Add-Member -MemberType NoteProperty -Name "User" -Value $sendOB
                                $mobj | Add-Member -MemberType NoteProperty -Name "Status" -Value 'Successful'
                                $mobj | Add-Member -MemberType NoteProperty -Name "Comment" -Value ''
                                $ret += $mobj
                            }
                        }
                        else
                        {
                            Log-Info 'No user or group is assigned "Send on behalf" permission for the source group.' -ConsoleInfo $false                       
                        }
                        Log-Info "Successfully retrieved the ""Send on behalf"" permission of the group ""$($sourceAddress)""." 
                        $hasSuccessfulObject = $true
                    }
                    catch
                    {
                        $errorMessage = "Failed to retrieve the ""Send on behalf"" permission of the group ""$($sourceAddress)"". Details: $($_.Exception.Message)"
                        Log-Error -Message $errorMessage
                        $mobj = New-Object -TypeName PSCustomObject
                        $mobj | Add-Member -MemberType NoteProperty -Name "Source Email Address" -Value $sourceAddress
                        $mobj | Add-Member -MemberType NoteProperty -Name "Source Type" -Value $mailbox.'Source Type'
                        $mobj | Add-Member -MemberType NoteProperty -Name "Destination Email Address" -Value $destTrimmedAddress
                        $mobj | Add-Member -MemberType NoteProperty -Name "Destination Type" -Value $mailbox.'Destination Type'  
                        $mobj | Add-Member -MemberType NoteProperty -Name "Type" -Value 'Send On Behalf'
                        $mobj | Add-Member -MemberType NoteProperty -Name "User" -Value ''
                        $mobj | Add-Member -MemberType NoteProperty -Name "Status" -Value 'Failed'
                        $mobj | Add-Member -MemberType NoteProperty -Name "Comment" -Value $errorMessage
                        $ret += $mobj
                    }

                    if ($hasPermissions -eq $false)
                    {
                        $mobj = New-Object -TypeName PSCustomObject
                        $mobj | Add-Member -MemberType NoteProperty -Name "Source Email Address" -Value $sourceAddress
                        $mobj | Add-Member -MemberType NoteProperty -Name "Source Type" -Value $mailbox.'Source Type'
                        $mobj | Add-Member -MemberType NoteProperty -Name "Destination Email Address" -Value $destTrimmedAddress
                        $mobj | Add-Member -MemberType NoteProperty -Name "Destination Type" -Value $mailbox.'Destination Type' 
                        $mobj | Add-Member -MemberType NoteProperty -Name "Type" -Value 'All permissions'
                        $mobj | Add-Member -MemberType NoteProperty -Name "User" -Value ''
                        $mobj | Add-Member -MemberType NoteProperty -Name "Status" -Value 'Successful'
                        $mobj | Add-Member -MemberType NoteProperty -Name "Comment" -Value 'The source group does not have any permission.'
                        $ret += $mobj
                    }
                }

                if ($hasSuccessfulObject -eq $false)
                {
                    $failedGroupCount ++
                }
            }
            else
            {
                $failedGroupCount ++
                $errorMessage = "There is no source or destination group email address configured in the `"GroupMappings.csv`" file."
                Log-Error -Message $errorMessage
                $mobj = New-Object -TypeName PSCustomObject
                $mobj | Add-Member -MemberType NoteProperty -Name "Source Email Address" -Value $mailbox.'Source Email Address'
                $mobj | Add-Member -MemberType NoteProperty -Name "Source Type" -Value $mailbox.'Source Type'
                $mobj | Add-Member -MemberType NoteProperty -Name "Destination Email Address" -Value $mailbox.'Destination Email Address'
                $mobj | Add-Member -MemberType NoteProperty -Name "Destination Type" -Value $mailbox.'Destination Type'   
                $mobj | Add-Member -MemberType NoteProperty -Name "Type" -Value 'All'
                $mobj | Add-Member -MemberType NoteProperty -Name "User" -Value ''
                $mobj | Add-Member -MemberType NoteProperty -Name "Status" -Value 'Failed'
                $mobj | Add-Member -MemberType NoteProperty -Name "Comment" -Value $errorMessage
                $ret += $mobj
            }
        }
        $ret | Export-Csv -Path $reportPath -NoTypeInformation -Encoding UTF8 
    }
    else
    {
        Log-Error -Message "Job failed. The `"GroupMappings.csv`" file in the $($csvPath) directory is empty."
        exit
    }
}
catch
{
    Log-Error -Message "An error occurred. Details: $($_.Exception.Message)"
    Log-Error -Message "An error occurred. Details: $($_.Exception)" -ConsoleInfo $false
}

Log-Info "failedGroupCount:$($failedGroupCount). TotalCount:$($totalCount)" -ConsoleInfo $false
if($failedGroupCount -eq 0 -and $totalCount -gt 0)
{
    Write-Host "Job finished. You can check the job report in the $($reportPath) directory." -ForegroundColor Green
    Log-Info "Job finished. You can check the job report in the $($reportPath) directory." -ConsoleInfo $false
}
elseif($failedGroupCount -lt $totalCount)
{
    Write-Host "Job finished with exception. You can check the job report in the $($reportPath) directory and the job logs in the $($logFullPath) directory." -ForegroundColor Yellow
    Log-Warning "Job finished with exception. You can check the job report in the $($reportPath) directory and the job logs in the $($logFullPath) directory." -ConsoleInfo $false
}
else
{
    Write-Host "Job failed. You can check the job report in the $($reportPath) directory and the job logs in the $($logFullPath) directory." -ForegroundColor Red
    Log-Error -Message "Job failed. You can check the job report in the $($reportPath) directory and the job logs in the $($logFullPath) directory." -ConsoleInfo $false
}
# SIG # Begin signature block
# MIIoHQYJKoZIhvcNAQcCoIIoDjCCKAoCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCcfcXVNlrxN7Hu
# cGZZGBm6r4peZESd27P0kbQ04pAlCaCCDZowggawMIIEmKADAgECAhAIrUCyYNKc
# TJ9ezam9k67ZMA0GCSqGSIb3DQEBDAUAMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQK
# EwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNV
# BAMTGERpZ2lDZXJ0IFRydXN0ZWQgUm9vdCBHNDAeFw0yMTA0MjkwMDAwMDBaFw0z
# NjA0MjgyMzU5NTlaMGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwg
# SW5jLjFBMD8GA1UEAxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBDb2RlIFNpZ25pbmcg
# UlNBNDA5NiBTSEEzODQgMjAyMSBDQTEwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAw
# ggIKAoICAQDVtC9C0CiteLdd1TlZG7GIQvUzjOs9gZdwxbvEhSYwn6SOaNhc9es0
# JAfhS0/TeEP0F9ce2vnS1WcaUk8OoVf8iJnBkcyBAz5NcCRks43iCH00fUyAVxJr
# Q5qZ8sU7H/Lvy0daE6ZMswEgJfMQ04uy+wjwiuCdCcBlp/qYgEk1hz1RGeiQIXhF
# LqGfLOEYwhrMxe6TSXBCMo/7xuoc82VokaJNTIIRSFJo3hC9FFdd6BgTZcV/sk+F
# LEikVoQ11vkunKoAFdE3/hoGlMJ8yOobMubKwvSnowMOdKWvObarYBLj6Na59zHh
# 3K3kGKDYwSNHR7OhD26jq22YBoMbt2pnLdK9RBqSEIGPsDsJ18ebMlrC/2pgVItJ
# wZPt4bRc4G/rJvmM1bL5OBDm6s6R9b7T+2+TYTRcvJNFKIM2KmYoX7BzzosmJQay
# g9Rc9hUZTO1i4F4z8ujo7AqnsAMrkbI2eb73rQgedaZlzLvjSFDzd5Ea/ttQokbI
# YViY9XwCFjyDKK05huzUtw1T0PhH5nUwjewwk3YUpltLXXRhTT8SkXbev1jLchAp
# QfDVxW0mdmgRQRNYmtwmKwH0iU1Z23jPgUo+QEdfyYFQc4UQIyFZYIpkVMHMIRro
# OBl8ZhzNeDhFMJlP/2NPTLuqDQhTQXxYPUez+rbsjDIJAsxsPAxWEQIDAQABo4IB
# WTCCAVUwEgYDVR0TAQH/BAgwBgEB/wIBADAdBgNVHQ4EFgQUaDfg67Y7+F8Rhvv+
# YXsIiGX0TkIwHwYDVR0jBBgwFoAU7NfjgtJxXWRM3y5nP+e6mK4cD08wDgYDVR0P
# AQH/BAQDAgGGMBMGA1UdJQQMMAoGCCsGAQUFBwMDMHcGCCsGAQUFBwEBBGswaTAk
# BggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNlcnQuY29tMEEGCCsGAQUFBzAC
# hjVodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkUm9v
# dEc0LmNydDBDBgNVHR8EPDA6MDigNqA0hjJodHRwOi8vY3JsMy5kaWdpY2VydC5j
# b20vRGlnaUNlcnRUcnVzdGVkUm9vdEc0LmNybDAcBgNVHSAEFTATMAcGBWeBDAED
# MAgGBmeBDAEEATANBgkqhkiG9w0BAQwFAAOCAgEAOiNEPY0Idu6PvDqZ01bgAhql
# +Eg08yy25nRm95RysQDKr2wwJxMSnpBEn0v9nqN8JtU3vDpdSG2V1T9J9Ce7FoFF
# UP2cvbaF4HZ+N3HLIvdaqpDP9ZNq4+sg0dVQeYiaiorBtr2hSBh+3NiAGhEZGM1h
# mYFW9snjdufE5BtfQ/g+lP92OT2e1JnPSt0o618moZVYSNUa/tcnP/2Q0XaG3Ryw
# YFzzDaju4ImhvTnhOE7abrs2nfvlIVNaw8rpavGiPttDuDPITzgUkpn13c5Ubdld
# AhQfQDN8A+KVssIhdXNSy0bYxDQcoqVLjc1vdjcshT8azibpGL6QB7BDf5WIIIJw
# 8MzK7/0pNVwfiThV9zeKiwmhywvpMRr/LhlcOXHhvpynCgbWJme3kuZOX956rEnP
# LqR0kq3bPKSchh/jwVYbKyP/j7XqiHtwa+aguv06P0WmxOgWkVKLQcBIhEuWTatE
# QOON8BUozu3xGFYHKi8QxAwIZDwzj64ojDzLj4gLDb879M4ee47vtevLt/B3E+bn
# KD+sEq6lLyJsQfmCXBVmzGwOysWGw/YmMwwHS6DTBwJqakAwSEs0qFEgu60bhQji
# WQ1tygVQK+pKHJ6l/aCnHwZ05/LWUpD9r4VIIflXO7ScA+2GRfS0YW6/aOImYIbq
# yK+p/pQd52MbOoZWeE4wggbiMIIEyqADAgECAhAPc9sqd/BkUUsWn0FQMB0UMA0G
# CSqGSIb3DQEBCwUAMGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwg
# SW5jLjFBMD8GA1UEAxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBDb2RlIFNpZ25pbmcg
# UlNBNDA5NiBTSEEzODQgMjAyMSBDQTEwHhcNMjMxMTAzMDAwMDAwWhcNMjYxMTE0
# MjM1OTU5WjBqMQswCQYDVQQGEwJVUzETMBEGA1UECBMKTmV3IEplcnNleTEUMBIG
# A1UEBxMLSmVyc2V5IENpdHkxFzAVBgNVBAoTDkF2ZVBvaW50LCBJbmMuMRcwFQYD
# VQQDEw5BdmVQb2ludCwgSW5jLjCCAaIwDQYJKoZIhvcNAQEBBQADggGPADCCAYoC
# ggGBAOEW7Ii2pvR9/732eojqygVHkWY2HMdaefS7g4Z4EOt6ABrXYcTFvIMax1DN
# 7ZCbfarSe6B0jsXnrNbhTZKJiphzbLAIs4NOi4EMxdWzDbc8oZqByMX77NxSiaR3
# PhqFGI99Utr9NUIBsruS6AccQ6CkP2nNejixv6BrsGJbUDrgz6A66x7V4WhYa6df
# qmMU8EucSyjcZB2A4h21H+jURe95N1SZThOw6vfFKn5JPnKvGTCuH0u19xi8d90j
# ZItOntrR92wzFG2jSd4Z3DeKyvIDWxGGqaDqloA7thXNGN/URNqTZfeXdsF6uUU2
# IojpWh8gYBTnu9i8cM9PVDOB420h5JaV+1XLO8m10LtnYBSWZWgUHpcTq7Suwbah
# 0/yiur0ltzR13dQ0wk2Xe1i/G8PlKw4IlyqESqizT3YxUGlqwcojIAYwaGBtATTf
# kCKq32rornXSmCqfrQICoA8dR7pry8hl/JloSD/+riT62F8r8mQTlLUw5xNiqBqE
# kIQvuQIDAQABo4ICAzCCAf8wHwYDVR0jBBgwFoAUaDfg67Y7+F8Rhvv+YXsIiGX0
# TkIwHQYDVR0OBBYEFJxiV1oIFotUW4UTNkwFNyJScORPMD4GA1UdIAQ3MDUwMwYG
# Z4EMAQQBMCkwJwYIKwYBBQUHAgEWG2h0dHA6Ly93d3cuZGlnaWNlcnQuY29tL0NQ
# UzAOBgNVHQ8BAf8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwgbUGA1UdHwSB
# rTCBqjBToFGgT4ZNaHR0cDovL2NybDMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0VHJ1
# c3RlZEc0Q29kZVNpZ25pbmdSU0E0MDk2U0hBMzg0MjAyMUNBMS5jcmwwU6BRoE+G
# TWh0dHA6Ly9jcmw0LmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydFRydXN0ZWRHNENvZGVT
# aWduaW5nUlNBNDA5NlNIQTM4NDIwMjFDQTEuY3JsMIGUBggrBgEFBQcBAQSBhzCB
# hDAkBggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNlcnQuY29tMFwGCCsGAQUF
# BzAChlBodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVk
# RzRDb2RlU2lnbmluZ1JTQTQwOTZTSEEzODQyMDIxQ0ExLmNydDAJBgNVHRMEAjAA
# MA0GCSqGSIb3DQEBCwUAA4ICAQDE9SZRwvtvpHrw4OjJ1AKL0aabKlOUkxidOjEC
# wrWr4yFKJdHWHpouUFTye7M8gQS4FQDQqD4ys7a1joCQVd+WEiQIyy0TzJXxT7US
# tkhg8lD41cT7i857dgnSrX7Prp0Es/xFBhEKR0fMs3Sj20+qcnJNTB4TA9CPnUd4
# UL1Ve/bqsr5lVZgoPp6wbs0lXjsTEfzrio++T4ssc42eTxfv6YZgTmdrPEQNqLUa
# hQuQ0x5j8lVBBtt5PrC7TikkVB/GBZ+01EJrUQvcX3arZky1tviINBQ3EXRhyGkx
# zSz6Vk9NxwJVkdavIUkdDuUuqNVqp2a3Zsv2L3mwlr0UnKMgpBiPnxgC9u6e5tjR
# +plDe3fmD20XQTt/p61FueC7w92HC6YizDrynRX58h6KuRv2j/u2yZU3nipaiGlz
# 8jURf2ySxZXI2QG228Nfsg4y1Z61tPfYb4kcqTfVcaxh7azpP6BU33dkIyC7dmv4
# q3PueRcSyweKjqlQqeswnTeBS3+met1BbjkMdJJzqbIu5WONTBIHHH1RGsQYPn8i
# ms3pE0GhGl9c1r1BpufehQwSjCZRc/vHrHUOQyNimVKoOtls5UAxU5FXO3PKaHPO
# M6dFS1b+EF6drXV0M9/KdJVyyP4EK6CJQVt7RrQBRSSdQCKCYJ63VUF5amRuzY0s
# EqLoRTGCGdkwghnVAgEBMH0waTELMAkGA1UEBhMCVVMxFzAVBgNVBAoTDkRpZ2lD
# ZXJ0LCBJbmMuMUEwPwYDVQQDEzhEaWdpQ2VydCBUcnVzdGVkIEc0IENvZGUgU2ln
# bmluZyBSU0E0MDk2IFNIQTM4NCAyMDIxIENBMQIQD3PbKnfwZFFLFp9BUDAdFDAN
# BglghkgBZQMEAgEFAKB8MBAGCisGAQQBgjcCAQwxAjAAMBkGCSqGSIb3DQEJAzEM
# BgorBgEEAYI3AgEEMBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMC8GCSqG
# SIb3DQEJBDEiBCCh3ebHtfTLoRK8IG7YgXEoCY3W0Bmu3t8ilCiy1ZcmejANBgkq
# hkiG9w0BAQEFAASCAYCuwlj665CQnuWUt9qLUEII6AJx97yfjZKUaF1lCeugdsiy
# yElRx/egQ9+HvHaKoypElfidvsiDCBhHIWuXDzcIasi61mQRMsk6Tv1erm9oafwN
# WchZSNEikmcIbcWqvFTVE5ByUhRS/6/SE5Og/hnH7Jpvhd++lx421BGYv+IeOvGc
# xylyirMGsl7WG4qbCtQoy+X7P2WhDOWLfxQNK/ORTHBAHSNHNPnpXNFZe0UTglcQ
# /TTgE6UmhkuK6BdRoQYZkRBGuSVesb8h+DMJLWCaMYeJ18QRE+EkITpA8YNRIlgu
# q8/lmw8/sSTtXloDmUF3s5msJHhb1TlIR/OpvyM0glpq57KtfeA/ydBQt2bHoPif
# uQMZzzBp1Ft9E59d5pWZQ387NVpLU0emN3+P/XqpdcIB7amAm7oVjaFh5sNrf3Et
# 1BjQvx4RjAwwckHrfG113tmPOJdx1fb7m3c6Kf0v+nYU1cxb96X2EHQcXp+YEyVk
# +ayzPEZk24zv9VebnsOhghcvMIIXKwYKKwYBBAGCNwMDATGCFxswghcXBgkqhkiG
# 9w0BBwKgghcIMIIXBAIBAzEPMA0GCWCGSAFlAwQCAQUAMGcGCyqGSIb3DQEJEAEE
# oFgEVjBUAgEBBglghkgBhv1sBwEwITAJBgUrDgMCGgUABBQAyw365XmRBZ4tXWmU
# z+anfaOTeQIQKgAVWL40+J4ceh5gUD3DChgPMjAyNDA4MDgwNTIwMjBaoIITCTCC
# BsIwggSqoAMCAQICEAVEr/OUnQg5pr/bP1/lYRYwDQYJKoZIhvcNAQELBQAwYzEL
# MAkGA1UEBhMCVVMxFzAVBgNVBAoTDkRpZ2lDZXJ0LCBJbmMuMTswOQYDVQQDEzJE
# aWdpQ2VydCBUcnVzdGVkIEc0IFJTQTQwOTYgU0hBMjU2IFRpbWVTdGFtcGluZyBD
# QTAeFw0yMzA3MTQwMDAwMDBaFw0zNDEwMTMyMzU5NTlaMEgxCzAJBgNVBAYTAlVT
# MRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjEgMB4GA1UEAxMXRGlnaUNlcnQgVGlt
# ZXN0YW1wIDIwMjMwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQCjU0WH
# HYOOW6w+VLMj4M+f1+XS512hDgncL0ijl3o7Kpxn3GIVWMGpkxGnzaqyat0QKYoe
# YmNp01icNXG/OpfrlFCPHCDqx5o7L5Zm42nnaf5bw9YrIBzBl5S0pVCB8s/LB6Yw
# aMqDQtr8fwkklKSCGtpqutg7yl3eGRiF+0XqDWFsnf5xXsQGmjzwxS55DxtmUuPI
# 1j5f2kPThPXQx/ZILV5FdZZ1/t0QoRuDwbjmUpW1R9d4KTlr4HhZl+NEK0rVlc7v
# CBfqgmRN/yPjyobutKQhZHDr1eWg2mOzLukF7qr2JPUdvJscsrdf3/Dudn0xmWVH
# VZ1KJC+sK5e+n+T9e3M+Mu5SNPvUu+vUoCw0m+PebmQZBzcBkQ8ctVHNqkxmg4ho
# Yru8QRt4GW3k2Q/gWEH72LEs4VGvtK0VBhTqYggT02kefGRNnQ/fztFejKqrUBXJ
# s8q818Q7aESjpTtC/XN97t0K/3k0EH6mXApYTAA+hWl1x4Nk1nXNjxJ2VqUk+tfE
# ayG66B80mC866msBsPf7Kobse1I4qZgJoXGybHGvPrhvltXhEBP+YUcKjP7wtsfV
# x95sJPC/QoLKoHE9nJKTBLRpcCcNT7e1NtHJXwikcKPsCvERLmTgyyIryvEoEyFJ
# UX4GZtM7vvrrkTjYUQfKlLfiUKHzOtOKg8tAewIDAQABo4IBizCCAYcwDgYDVR0P
# AQH/BAQDAgeAMAwGA1UdEwEB/wQCMAAwFgYDVR0lAQH/BAwwCgYIKwYBBQUHAwgw
# IAYDVR0gBBkwFzAIBgZngQwBBAIwCwYJYIZIAYb9bAcBMB8GA1UdIwQYMBaAFLoW
# 2W1NhS9zKXaaL3WMaiCPnshvMB0GA1UdDgQWBBSltu8T5+/N0GSh1VapZTGj3tXj
# STBaBgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsMy5kaWdpY2VydC5jb20vRGln
# aUNlcnRUcnVzdGVkRzRSU0E0MDk2U0hBMjU2VGltZVN0YW1waW5nQ0EuY3JsMIGQ
# BggrBgEFBQcBAQSBgzCBgDAkBggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNl
# cnQuY29tMFgGCCsGAQUFBzAChkxodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20v
# RGlnaUNlcnRUcnVzdGVkRzRSU0E0MDk2U0hBMjU2VGltZVN0YW1waW5nQ0EuY3J0
# MA0GCSqGSIb3DQEBCwUAA4ICAQCBGtbeoKm1mBe8cI1PijxonNgl/8ss5M3qXSKS
# 7IwiAqm4z4Co2efjxe0mgopxLxjdTrbebNfhYJwr7e09SI64a7p8Xb3CYTdoSXej
# 65CqEtcnhfOOHpLawkA4n13IoC4leCWdKgV6hCmYtld5j9smViuw86e9NwzYmHZP
# VrlSwradOKmB521BXIxp0bkrxMZ7z5z6eOKTGnaiaXXTUOREEr4gDZ6pRND45Ul3
# CFohxbTPmJUaVLq5vMFpGbrPFvKDNzRusEEm3d5al08zjdSNd311RaGlWCZqA0Xe
# 2VC1UIyvVr1MxeFGxSjTredDAHDezJieGYkD6tSRN+9NUvPJYCHEVkft2hFLjDLD
# iOZY4rbbPvlfsELWj+MXkdGqwFXjhr+sJyxB0JozSqg21Llyln6XeThIX8rC3D0y
# 33XWNmdaifj2p8flTzU8AL2+nCpseQHc2kTmOt44OwdeOVj0fHMxVaCAEcsUDH6u
# vP6k63llqmjWIso765qCNVcoFstp8jKastLYOrixRoZruhf9xHdsFWyuq69zOuhJ
# RrfVf8y2OMDY7Bz1tqG4QyzfTkx9HmhwwHcK1ALgXGC7KP845VJa1qwXIiNO9OzT
# F/tQa/8Hdx9xl0RBybhG02wyfFgvZ0dl5Rtztpn5aywGRu9BHvDwX+Db2a2QgESv
# gBBBijCCBq4wggSWoAMCAQICEAc2N7ckVHzYR6z9KGYqXlswDQYJKoZIhvcNAQEL
# BQAwYjELMAkGA1UEBhMCVVMxFTATBgNVBAoTDERpZ2lDZXJ0IEluYzEZMBcGA1UE
# CxMQd3d3LmRpZ2ljZXJ0LmNvbTEhMB8GA1UEAxMYRGlnaUNlcnQgVHJ1c3RlZCBS
# b290IEc0MB4XDTIyMDMyMzAwMDAwMFoXDTM3MDMyMjIzNTk1OVowYzELMAkGA1UE
# BhMCVVMxFzAVBgNVBAoTDkRpZ2lDZXJ0LCBJbmMuMTswOQYDVQQDEzJEaWdpQ2Vy
# dCBUcnVzdGVkIEc0IFJTQTQwOTYgU0hBMjU2IFRpbWVTdGFtcGluZyBDQTCCAiIw
# DQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBAMaGNQZJs8E9cklRVcclA8TykTep
# l1Gh1tKD0Z5Mom2gsMyD+Vr2EaFEFUJfpIjzaPp985yJC3+dH54PMx9QEwsmc5Zt
# +FeoAn39Q7SE2hHxc7Gz7iuAhIoiGN/r2j3EF3+rGSs+QtxnjupRPfDWVtTnKC3r
# 07G1decfBmWNlCnT2exp39mQh0YAe9tEQYncfGpXevA3eZ9drMvohGS0UvJ2R/dh
# gxndX7RUCyFobjchu0CsX7LeSn3O9TkSZ+8OpWNs5KbFHc02DVzV5huowWR0QKfA
# csW6Th+xtVhNef7Xj3OTrCw54qVI1vCwMROpVymWJy71h6aPTnYVVSZwmCZ/oBpH
# IEPjQ2OAe3VuJyWQmDo4EbP29p7mO1vsgd4iFNmCKseSv6De4z6ic/rnH1pslPJS
# lRErWHRAKKtzQ87fSqEcazjFKfPKqpZzQmiftkaznTqj1QPgv/CiPMpC3BhIfxQ0
# z9JMq++bPf4OuGQq+nUoJEHtQr8FnGZJUlD0UfM2SU2LINIsVzV5K6jzRWC8I41Y
# 99xh3pP+OcD5sjClTNfpmEpYPtMDiP6zj9NeS3YSUZPJjAw7W4oiqMEmCPkUEBID
# fV8ju2TjY+Cm4T72wnSyPx4JduyrXUZ14mCjWAkBKAAOhFTuzuldyF4wEr1GnrXT
# drnSDmuZDNIztM2xAgMBAAGjggFdMIIBWTASBgNVHRMBAf8ECDAGAQH/AgEAMB0G
# A1UdDgQWBBS6FtltTYUvcyl2mi91jGogj57IbzAfBgNVHSMEGDAWgBTs1+OC0nFd
# ZEzfLmc/57qYrhwPTzAOBgNVHQ8BAf8EBAMCAYYwEwYDVR0lBAwwCgYIKwYBBQUH
# AwgwdwYIKwYBBQUHAQEEazBpMCQGCCsGAQUFBzABhhhodHRwOi8vb2NzcC5kaWdp
# Y2VydC5jb20wQQYIKwYBBQUHMAKGNWh0dHA6Ly9jYWNlcnRzLmRpZ2ljZXJ0LmNv
# bS9EaWdpQ2VydFRydXN0ZWRSb290RzQuY3J0MEMGA1UdHwQ8MDowOKA2oDSGMmh0
# dHA6Ly9jcmwzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydFRydXN0ZWRSb290RzQuY3Js
# MCAGA1UdIAQZMBcwCAYGZ4EMAQQCMAsGCWCGSAGG/WwHATANBgkqhkiG9w0BAQsF
# AAOCAgEAfVmOwJO2b5ipRCIBfmbW2CFC4bAYLhBNE88wU86/GPvHUF3iSyn7cIoN
# qilp/GnBzx0H6T5gyNgL5Vxb122H+oQgJTQxZ822EpZvxFBMYh0MCIKoFr2pVs8V
# c40BIiXOlWk/R3f7cnQU1/+rT4osequFzUNf7WC2qk+RZp4snuCKrOX9jLxkJods
# kr2dfNBwCnzvqLx1T7pa96kQsl3p/yhUifDVinF2ZdrM8HKjI/rAJ4JErpknG6sk
# HibBt94q6/aesXmZgaNWhqsKRcnfxI2g55j7+6adcq/Ex8HBanHZxhOACcS2n82H
# hyS7T6NJuXdmkfFynOlLAlKnN36TU6w7HQhJD5TNOXrd/yVjmScsPT9rp/Fmw0HN
# T7ZAmyEhQNC3EyTN3B14OuSereU0cZLXJmvkOHOrpgFPvT87eK1MrfvElXvtCl8z
# OYdBeHo46Zzh3SP9HSjTx/no8Zhf+yvYfvJGnXUsHicsJttvFXseGYs2uJPU5vIX
# mVnKcPA3v5gA3yAWTyf7YGcWoWa63VXAOimGsJigK+2VQbc61RWYMbRiCQ8KvYHZ
# E/6/pNHzV9m8BPqC3jLfBInwAM1dwvnQI38AC+R2AibZ8GV2QqYphwlHK+Z/GqSF
# D/yYlvZVVCsfgPrA8g4r5db7qS9EFUrnEw4d2zc4GqEr9u3WfPwwggWNMIIEdaAD
# AgECAhAOmxiO+dAt5+/bUOIIQBhaMA0GCSqGSIb3DQEBDAUAMGUxCzAJBgNVBAYT
# AlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2Vy
# dC5jb20xJDAiBgNVBAMTG0RpZ2lDZXJ0IEFzc3VyZWQgSUQgUm9vdCBDQTAeFw0y
# MjA4MDEwMDAwMDBaFw0zMTExMDkyMzU5NTlaMGIxCzAJBgNVBAYTAlVTMRUwEwYD
# VQQKEwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAf
# BgNVBAMTGERpZ2lDZXJ0IFRydXN0ZWQgUm9vdCBHNDCCAiIwDQYJKoZIhvcNAQEB
# BQADggIPADCCAgoCggIBAL/mkHNo3rvkXUo8MCIwaTPswqclLskhPfKK2FnC4Smn
# PVirdprNrnsbhA3EMB/zG6Q4FutWxpdtHauyefLKEdLkX9YFPFIPUh/GnhWlfr6f
# qVcWWVVyr2iTcMKyunWZanMylNEQRBAu34LzB4TmdDttceItDBvuINXJIB1jKS3O
# 7F5OyJP4IWGbNOsFxl7sWxq868nPzaw0QF+xembud8hIqGZXV59UWI4MK7dPpzDZ
# Vu7Ke13jrclPXuU15zHL2pNe3I6PgNq2kZhAkHnDeMe2scS1ahg4AxCN2NQ3pC4F
# fYj1gj4QkXCrVYJBMtfbBHMqbpEBfCFM1LyuGwN1XXhm2ToxRJozQL8I11pJpMLm
# qaBn3aQnvKFPObURWBf3JFxGj2T3wWmIdph2PVldQnaHiZdpekjw4KISG2aadMre
# Sx7nDmOu5tTvkpI6nj3cAORFJYm2mkQZK37AlLTSYW3rM9nF30sEAMx9HJXDj/ch
# srIRt7t/8tWMcCxBYKqxYxhElRp2Yn72gLD76GSmM9GJB+G9t+ZDpBi4pncB4Q+U
# DCEdslQpJYls5Q5SUUd0viastkF13nqsX40/ybzTQRESW+UQUOsxxcpyFiIJ33xM
# dT9j7CFfxCBRa2+xq4aLT8LWRV+dIPyhHsXAj6KxfgommfXkaS+YHS312amyHeUb
# AgMBAAGjggE6MIIBNjAPBgNVHRMBAf8EBTADAQH/MB0GA1UdDgQWBBTs1+OC0nFd
# ZEzfLmc/57qYrhwPTzAfBgNVHSMEGDAWgBRF66Kv9JLLgjEtUYunpyGd823IDzAO
# BgNVHQ8BAf8EBAMCAYYweQYIKwYBBQUHAQEEbTBrMCQGCCsGAQUFBzABhhhodHRw
# Oi8vb2NzcC5kaWdpY2VydC5jb20wQwYIKwYBBQUHMAKGN2h0dHA6Ly9jYWNlcnRz
# LmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydEFzc3VyZWRJRFJvb3RDQS5jcnQwRQYDVR0f
# BD4wPDA6oDigNoY0aHR0cDovL2NybDMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0QXNz
# dXJlZElEUm9vdENBLmNybDARBgNVHSAECjAIMAYGBFUdIAAwDQYJKoZIhvcNAQEM
# BQADggEBAHCgv0NcVec4X6CjdBs9thbX979XB72arKGHLOyFXqkauyL4hxppVCLt
# pIh3bb0aFPQTSnovLbc47/T/gLn4offyct4kvFIDyE7QKt76LVbP+fT3rDB6mouy
# XtTP0UNEm0Mh65ZyoUi0mcudT6cGAxN3J0TU53/oWajwvy8LpunyNDzs9wPHh6jS
# TEAZNUZqaVSwuKFWjuyk1T3osdz9HNj0d1pcVIxv76FQPfx2CWiEn2/K2yCNNWAc
# AgPLILCsWKAOQGPFmCLBsln1VWvPJ6tsds5vIy30fnFqI2si/xK4VC0nftg62fC2
# h5b9W9FcrBjDTZ9ztwGpn1eqXijiuZQxggN2MIIDcgIBATB3MGMxCzAJBgNVBAYT
# AlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjE7MDkGA1UEAxMyRGlnaUNlcnQg
# VHJ1c3RlZCBHNCBSU0E0MDk2IFNIQTI1NiBUaW1lU3RhbXBpbmcgQ0ECEAVEr/OU
# nQg5pr/bP1/lYRYwDQYJYIZIAWUDBAIBBQCggdEwGgYJKoZIhvcNAQkDMQ0GCyqG
# SIb3DQEJEAEEMBwGCSqGSIb3DQEJBTEPFw0yNDA4MDgwNTIwMjBaMCsGCyqGSIb3
# DQEJEAIMMRwwGjAYMBYEFGbwKzLCwskPgl3OqorJxk8ZnM9AMC8GCSqGSIb3DQEJ
# BDEiBCDeHAUI2zwS1OuhYJbWudMz+IFoS5GJgs4ZO0chIt/AGTA3BgsqhkiG9w0B
# CRACLzEoMCYwJDAiBCDS9uRt7XQizNHUQFdoQTZvgoraVZquMxavTRqa1Ax4KDAN
# BgkqhkiG9w0BAQEFAASCAgBMP5FiasOktJ0o/qs2qQ29MOAikLIFxDz338WH7esz
# R3uXaVOu+nxKLVbE3DcqSToPSafMflXTQrzHQqBmWIkVkPe4idAZ4Y73rRFL5kqR
# +O4UmoTsqr/7WMnqv3XUCKwxuFXlAF1fOc9bOSD6Z5d7n/hyS1ifmqMnBLE7/KCp
# 17hfZElT1andEfKHJurOXqeiNk7LWF0GXwV3/irlSR5oUNzGG5Rlhno14gkGqHDT
# CXc5L4SxRXPf6bqH6ViJuj2WfZ58OgAX8biz+V9Z8Fr4L+mw7h1l08oTzQQnW5Wi
# qyr1DjTEmdxi1xcj9oRZMPUTDrWpzsqYiJGtoVo8FUUic6AVJexZORQPdPOsQzCA
# rcUZCN2MzHXSK+4Gy4cSn0XIqPxCS7Mm+cdtVq12JkqsVSYd4BQKf700aivYfQTE
# tEP1UzdztRMJc2/H1YT3OVnq7ONjDvAHH5Oo/6BuYB0Abrv04d2s2UG72it8oMR3
# yxw53QW+V8uyLU7hroS8oCQOUit/w69QzJv55LR0iZ4Phr/q3d8zMvJT6E2DzHl1
# XZjFB0Ezmi9uH6peSODcC9NXMGZ42j5iYlG2zw2nJt5oqHBzs77UaOfsSfebcVLA
# HnILMhj3Nv8SAVxrp2KiWfa7nS5w8OHM0B/Oyqnv1kudnRE4EYob5RJ2ujuTahO6
# sQ==
# SIG # End signature block
